<?php
require_once __DIR__ . '/bedspace_bootstrap.php';

function bs_auth_start(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
}

function bs_password_hash_value(string $password): string
{
    return password_hash($password, PASSWORD_DEFAULT);
}

function bs_password_verify_value(string $password, ?string $stored): bool
{
    $stored = (string)$stored;
    if ($stored === '') {
        return false;
    }

    if (password_verify($password, $stored)) {
        return true;
    }

    if (strlen($stored) === 64 && ctype_xdigit($stored)) {
        return hash('sha256', $password) === strtolower($stored);
    }

    return false;
}

function bs_seed_staff_account(mysqli $conn): void
{
    $usersTable = bs_table('users');
    $username = 'frontdesk';
    $passwordHash = bs_password_hash_value('Staff@12345');

    $stmt = $conn->prepare("SELECT id FROM {$usersTable} WHERE username = ? LIMIT 1");
    if (!$stmt) {
        return;
    }
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $existing = $result->fetch_assoc();
    $stmt->close();

    if (!$existing) {
        $insert = $conn->prepare(
            "INSERT INTO {$usersTable} (username, password_hash, role, full_name)
             VALUES (?, ?, 'staff', 'Front Desk Staff')"
        );
        if ($insert) {
            $insert->bind_param('ss', $username, $passwordHash);
            $insert->execute();
            $insert->close();
        }
    }
}

function bs_login_staff(array $user): void
{
    bs_auth_start();
    $_SESSION['bedspace_role'] = 'staff';
    $_SESSION['bedspace_staff_id'] = (int)$user['id'];
    $_SESSION['bedspace_staff_name'] = (string)($user['full_name'] ?? $user['username']);
}

function bs_login_tenant(array $tenant): void
{
    bs_auth_start();
    $_SESSION['bedspace_role'] = 'tenant';
    $_SESSION['bedspace_tenant_id'] = (int)$tenant['id'];
    $_SESSION['bedspace_tenant_name'] = (string)$tenant['name'];
}

function bs_logout(): void
{
    bs_auth_start();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

function bs_require_staff(): void
{
    bs_auth_start();
    if (($_SESSION['bedspace_role'] ?? '') !== 'staff') {
        header('Location: employeelogin.php');
        exit();
    }
}

function bs_require_tenant(): void
{
    bs_auth_start();
    if (($_SESSION['bedspace_role'] ?? '') !== 'tenant') {
        header('Location: tenant_login.php');
        exit();
    }
}
