<?php
require_once __DIR__ . '/../bedspace_auth.php';

bs_require_staff();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BedSpace Employee Dashboard</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --navy: #0f172a;
      --surface: #f8fafc;
      --panel: #ffffff;
      --line: #e2e8f0;
      --text: #0f172a;
      --muted: #64748b;
      --primary: #3d8ef0;
      --green: #22c55e;
      --orange: #f59e0b;
    }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: "Inter", sans-serif; background: var(--surface); color: var(--text); }
    a { text-decoration: none; color: inherit; }
    .layout { min-height: 100vh; display: grid; grid-template-columns: 280px 1fr; }
    .sidebar {
      background: linear-gradient(180deg, #0f172a 0%, #172235 100%);
      color: #e2e8f0;
      padding: 24px 18px;
      display: flex;
      flex-direction: column;
      gap: 18px;
    }
    .brand { display: flex; gap: 14px; align-items: center; padding: 8px 10px 18px; border-bottom: 1px solid rgba(255,255,255,.08); }
    .mark {
      width: 48px; height: 48px; border-radius: 16px; display: grid; place-items: center;
      background: linear-gradient(135deg, #3d8ef0, #22c55e); font-size: 22px; box-shadow: 0 18px 36px rgba(61,142,240,.25);
    }
    .brand strong { display: block; font-size: 16px; }
    .brand span { color: #94a3b8; font-size: 11px; text-transform: uppercase; letter-spacing: .08em; }
    .section-label { color: #64748b; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; padding: 0 12px; }
    .nav-link {
      display: flex; align-items: center; gap: 12px; padding: 14px; border-radius: 16px;
      color: #cbd5e1; font-size: 14px; font-weight: 600;
    }
    .nav-link:hover, .nav-link.active { background: rgba(255,255,255,.08); color: #fff; }
    .content { padding: 28px; }
    .topbar { display: flex; justify-content: space-between; align-items: start; gap: 16px; margin-bottom: 24px; }
    .topbar h1 { margin: 0; font-size: 34px; letter-spacing: -.04em; }
    .topbar p { margin: 8px 0 0; color: var(--muted); }
    .badge {
      padding: 10px 14px; border-radius: 999px; background: #ecfdf5; color: #15803d;
      font-size: 12px; font-weight: 800;
    }
    .hero {
      background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%);
      color: #fff; border-radius: 28px; padding: 28px; display: grid; grid-template-columns: 1.1fr .9fr; gap: 18px;
      box-shadow: 0 24px 50px rgba(15,23,42,.16); margin-bottom: 22px;
    }
    .hero h2 { margin: 0 0 10px; font-size: 30px; line-height: 1.05; letter-spacing: -.04em; }
    .hero p { margin: 0 0 18px; color: rgba(255,255,255,.78); line-height: 1.75; }
    .stats { display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 12px; }
    .stat { padding: 16px; border-radius: 18px; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.10); }
    .stat strong { display: block; font-size: 26px; margin-bottom: 4px; }
    .stat span { font-size: 12px; color: rgba(255,255,255,.72); }
    .focus-box { background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.10); border-radius: 22px; padding: 20px; }
    .focus-box h3 { margin: 0 0 14px; font-size: 18px; }
    .focus-list { display: grid; gap: 10px; }
    .focus-item { padding: 14px 16px; background: rgba(255,255,255,.06); border-radius: 16px; }
    .focus-item strong { display: block; margin-bottom: 4px; font-size: 14px; }
    .focus-item span { font-size: 12px; color: rgba(255,255,255,.74); }
    .grid { display: grid; grid-template-columns: repeat(4, minmax(0,1fr)); gap: 16px; margin-bottom: 22px; }
    .card, .panel {
      background: var(--panel); border: 1px solid var(--line); border-radius: 22px;
      box-shadow: 0 12px 28px rgba(15,23,42,.05);
    }
    .card { padding: 20px; }
    .card .label { color: var(--muted); font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; }
    .card strong { display: block; font-size: 28px; margin: 10px 0 6px; letter-spacing: -.04em; }
    .card span { color: var(--muted); font-size: 13px; line-height: 1.6; }
    .lower { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
    .panel { padding: 22px; }
    .panel h3 { margin: 0 0 16px; font-size: 20px; letter-spacing: -.03em; }
    .action-grid { display: grid; grid-template-columns: repeat(2, minmax(0,1fr)); gap: 12px; }
    .action {
      padding: 18px; border-radius: 18px; border: 1px solid var(--line); background: #f8fafc;
    }
    .action strong { display: block; margin-bottom: 6px; font-size: 15px; }
    .action span { color: var(--muted); font-size: 12px; line-height: 1.6; }
    .queue { display: grid; gap: 10px; }
    .queue-item {
      display: flex; justify-content: space-between; gap: 12px; align-items: center;
      padding: 14px 16px; background: #f8fafc; border: 1px solid var(--line); border-radius: 16px;
    }
    .queue-item strong { display: block; margin-bottom: 4px; font-size: 14px; }
    .queue-item span { color: var(--muted); font-size: 12px; }
    .tag { padding: 8px 10px; border-radius: 999px; font-size: 11px; font-weight: 800; }
    .tag.blue { background: #dbeafe; color: #1d4ed8; }
    .tag.green { background: #dcfce7; color: #15803d; }
    .tag.orange { background: #fef3c7; color: #b45309; }
    @media (max-width: 1100px) { .grid { grid-template-columns: repeat(2, minmax(0,1fr)); } .lower, .hero { grid-template-columns: 1fr; } }
    @media (max-width: 800px) { .layout { grid-template-columns: 1fr; } .grid, .action-grid, .stats { grid-template-columns: 1fr; } }
  </style>
</head>
<body>
  <div class="layout">
    <aside class="sidebar">
      <div class="brand">
        <div class="mark">🧰</div>
        <div>
          <strong>BedSpace</strong>
          <span>Employee Ops</span>
        </div>
      </div>

      <div class="section-label">Workspace</div>
      <a class="nav-link" href="../Admin/admin_dashboard.php">📊 Admin View</a>
      <a class="nav-link active" href="empdashboard.php">🧰 Employee Dashboard</a>
      <a class="nav-link" href="../Tenant/tenant_dashboard.php">🧍 Tenant View</a>

      <div class="section-label">Tasks</div>
      <a class="nav-link" href="viewtenant.php">👥 Tenant Directory</a>
      <a class="nav-link" href="createtenant.php">➕ Create Tenant</a>
      <a class="nav-link" href="viewrequest.php">📋 Service Requests</a>
      <a class="nav-link" href="fees.php">💳 Fees</a>
      <a class="nav-link" href="../Admin/complaints.php">🛠 Complaints</a>
      <a class="nav-link" href="export.php">📤 Export Data</a>
      <a class="nav-link" href="../logout.php">Logout</a>
    </aside>

    <main class="content">
      <div class="topbar">
        <div>
          <h1>Employee Dashboard</h1>
          <p>Operations-focused BedSpacer workspace for tenant handling, service flow, and daily support.</p>
        </div>
        <div class="badge">Staff Operations Live</div>
      </div>

      <section class="hero">
        <div>
          <h2>Support tenants, handle requests, and keep daily operations moving.</h2>
          <p>
            This workspace now feels closer to BedSpacer operations: less generic admin chrome,
            more emphasis on queue handling, tenant management, and fast access to action pages.
          </p>
          <div class="stats">
            <div class="stat">
              <strong>Tenants</strong>
              <span>Create, edit, view, and support resident records.</span>
            </div>
            <div class="stat">
              <strong>Requests</strong>
              <span>Review incoming service requests and operational tasks.</span>
            </div>
            <div class="stat">
              <strong>Complaints</strong>
              <span>Track issue reports and follow-up resolution work.</span>
            </div>
          </div>
        </div>
        <div class="focus-box">
          <h3>Today’s focus</h3>
          <div class="focus-list">
            <div class="focus-item">
              <strong>Check tenant queue</strong>
              <span>Verify new signups, room-related updates, and tenant profile edits.</span>
            </div>
            <div class="focus-item">
              <strong>Handle service requests</strong>
              <span>Move requests forward and coordinate complaints with admin visibility.</span>
            </div>
            <div class="focus-item">
              <strong>Review payment activity</strong>
              <span>Keep maintenance fee and billing-related records easy to inspect.</span>
            </div>
          </div>
        </div>
      </section>

      <section class="grid">
        <article class="card">
          <div class="label">Residents</div>
          <strong>Tenant Desk</strong>
          <span>Open the tenant directory and manage resident profiles quickly.</span>
        </article>
        <article class="card">
          <div class="label">Onboarding</div>
          <strong>Create Tenant</strong>
          <span>Register new occupant records and support move-in operations.</span>
        </article>
        <article class="card">
          <div class="label">Support</div>
          <strong>Request Handling</strong>
          <span>Review service requests and keep issue handling visible.</span>
        </article>
        <article class="card">
          <div class="label">Finance</div>
          <strong>Fee Monitoring</strong>
          <span>Check payment-related pages without leaving the staff workspace.</span>
        </article>
      </section>

      <section class="lower">
        <article class="panel">
          <h3>Quick actions</h3>
          <div class="action-grid">
            <a class="action" href="viewtenant.php">
              <strong>View Tenants</strong>
              <span>Inspect all current tenant records.</span>
            </a>
            <a class="action" href="createtenant.php">
              <strong>Create Tenant</strong>
              <span>Add a new resident profile into the system.</span>
            </a>
            <a class="action" href="viewrequest.php">
              <strong>Review Requests</strong>
              <span>Open current service request handling.</span>
            </a>
            <a class="action" href="fees.php">
              <strong>Check Fees</strong>
              <span>Open fee and payment views for support work.</span>
            </a>
          </div>
        </article>

        <article class="panel">
          <h3>Operational queue</h3>
          <div class="queue">
            <div class="queue-item">
              <div>
                <strong>Tenant profile updates</strong>
                <span>Use edit and delete tools from the tenant screens.</span>
              </div>
              <div class="tag blue">Active</div>
            </div>
            <div class="queue-item">
              <div>
                <strong>Service requests</strong>
                <span>Inspect request approvals, denials, and assignment flow.</span>
              </div>
              <div class="tag orange">Pending</div>
            </div>
            <div class="queue-item">
              <div>
                <strong>Complaints visibility</strong>
                <span>Coordinate with the admin complaint view when needed.</span>
              </div>
              <div class="tag green">Shared</div>
            </div>
          </div>
        </article>
      </section>
    </main>
  </div>
</body>
</html>
