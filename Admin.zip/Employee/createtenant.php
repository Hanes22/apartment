<?php
require_once __DIR__ . '/../bedspace_auth.php';

bs_ensure_schema($conn);
bs_require_staff();

$tenantsTable = bs_table('tenants');
$bedsTable = bs_table('beds');
$roomsTable = bs_table('rooms');
$message = '';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $age = $_POST['age'] !== '' ? (int)$_POST['age'] : null;
    $contact = trim($_POST['contact'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $idNumber = trim($_POST['id_number'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $moveInDate = $_POST['move_in_date'] !== '' ? $_POST['move_in_date'] : null;
    $moveOutDate = $_POST['move_out_date'] !== '' ? $_POST['move_out_date'] : null;
    $bedId = $_POST['bed_id'] !== '' ? (int)$_POST['bed_id'] : null;
    $status = $_POST['status'] ?? 'Active';
    $paymentType = $_POST['payment_type'] ?? 'Monthly';
    $username = trim($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');
    $emergencyContact = trim($_POST['emergency_contact'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    if ($name === '') {
        $errors[] = 'Tenant name is required.';
    }

    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    }

    if ($username === '') {
        $errors[] = 'Username is required.';
    }

    if ($password === '') {
        $errors[] = 'Password is required.';
    }

    if ($username !== '') {
        $check = $conn->prepare("SELECT id FROM {$tenantsTable} WHERE username = ? LIMIT 1");
        $check->bind_param('s', $username);
        $check->execute();
        $existing = $check->get_result()->fetch_assoc();
        $check->close();
        if ($existing) {
            $errors[] = 'Username already exists.';
        }
    }

    if (!$errors) {
        $passwordHash = bs_password_hash_value($password);
        $stmt = $conn->prepare(
            "INSERT INTO {$tenantsTable}
             (name, age, contact, email, id_number, address, move_in_date, move_out_date, bed_id, status, payment_type, username, password_hash, emergency_contact, notes)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param(
            'sissssssissssss',
            $name,
            $age,
            $contact,
            $email,
            $idNumber,
            $address,
            $moveInDate,
            $moveOutDate,
            $bedId,
            $status,
            $paymentType,
            $username,
            $passwordHash,
            $emergencyContact,
            $notes
        );

        if ($stmt->execute()) {
            if ($bedId) {
                $bedStmt = $conn->prepare("UPDATE {$bedsTable} SET status='Occupied' WHERE id=?");
                $bedStmt->bind_param('i', $bedId);
                $bedStmt->execute();
                $bedStmt->close();
            }
            $message = 'Tenant created successfully.';
        } else {
            $errors[] = 'Unable to create tenant: ' . $stmt->error;
        }
        $stmt->close();
    }
}

$beds = $conn->query(
    "SELECT b.id, b.bed_number, b.status, r.name AS room_name
     FROM {$bedsTable} b
     LEFT JOIN {$roomsTable} r ON r.id = b.room_id
     ORDER BY r.name, b.bed_number"
)->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Tenant</title>
    <style>
        body {
            margin: 0;
            font-family: "Inter", Arial, sans-serif;
            background: #f8fafc;
            color: #0f172a;
            padding: 28px;
        }
        .wrap {
            max-width: 960px;
            margin: 0 auto;
        }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            margin-bottom: 24px;
        }
        .topbar h1 {
            margin: 0;
            font-size: 32px;
        }
        .topbar p {
            margin: 8px 0 0;
            color: #64748b;
        }
        .badge, .button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 12px 16px;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 700;
            border: none;
            cursor: pointer;
        }
        .badge {
            background: #eff6ff;
            color: #1d4ed8;
        }
        .button {
            background: linear-gradient(135deg, #3d8ef0, #1d4ed8);
            color: #fff;
        }
        .button.secondary {
            background: #e2e8f0;
            color: #0f172a;
        }
        .panel {
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 24px;
            box-shadow: 0 12px 28px rgba(15, 23, 42, 0.05);
            padding: 24px;
        }
        .notice {
            padding: 14px 16px;
            border-radius: 16px;
            margin-bottom: 16px;
        }
        .notice.success {
            background: #ecfdf5;
            color: #166534;
            border: 1px solid #bbf7d0;
        }
        .notice.error {
            background: #fef2f2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 16px;
        }
        .field {
            display: grid;
            gap: 8px;
        }
        .field.full {
            grid-column: 1 / -1;
        }
        label {
            font-size: 13px;
            font-weight: 700;
            color: #334155;
        }
        input, select, textarea {
            width: 100%;
            border-radius: 14px;
            border: 1px solid #cbd5e1;
            background: #fff;
            padding: 12px 14px;
            font: inherit;
            font-size: 14px;
            color: #0f172a;
        }
        textarea {
            min-height: 110px;
            resize: vertical;
        }
        .actions {
            display: flex;
            gap: 12px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        @media (max-width: 760px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            .topbar {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="topbar">
            <div>
                <h1>Create Tenant</h1>
                <p>Add a tenant record to the live BedSpacer tenant table.</p>
            </div>
            <div style="display:flex; gap:12px; flex-wrap:wrap;">
                <a class="badge" href="viewtenant.php">View Tenants</a>
                <a class="badge" href="empdashboard.php">Employee Dashboard</a>
            </div>
        </div>

        <?php if ($message !== ''): ?>
            <div class="notice success"><?php echo h($message); ?></div>
        <?php endif; ?>

        <?php if ($errors): ?>
            <div class="notice error"><?php echo h(implode(' ', $errors)); ?></div>
        <?php endif; ?>

        <div class="panel">
            <form method="post">
                <div class="form-grid">
                    <div class="field">
                        <label for="name">Tenant name</label>
                        <input type="text" id="name" name="name" value="<?php echo h($_POST['name'] ?? ''); ?>" required>
                    </div>
                    <div class="field">
                        <label for="age">Age</label>
                        <input type="number" id="age" name="age" value="<?php echo h($_POST['age'] ?? ''); ?>" min="0">
                    </div>
                    <div class="field">
                        <label for="contact">Contact number</label>
                        <input type="text" id="contact" name="contact" value="<?php echo h($_POST['contact'] ?? ''); ?>">
                    </div>
                    <div class="field">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo h($_POST['email'] ?? ''); ?>">
                    </div>
                    <div class="field">
                        <label for="username">Login username</label>
                        <input type="text" id="username" name="username" value="<?php echo h($_POST['username'] ?? ''); ?>" required>
                    </div>
                    <div class="field">
                        <label for="password">Login password</label>
                        <input type="text" id="password" name="password" value="<?php echo h($_POST['password'] ?? ''); ?>" required>
                    </div>
                    <div class="field">
                        <label for="id_number">ID number</label>
                        <input type="text" id="id_number" name="id_number" value="<?php echo h($_POST['id_number'] ?? ''); ?>">
                    </div>
                    <div class="field">
                        <label for="bed_id">Assigned bed</label>
                        <select id="bed_id" name="bed_id">
                            <option value="">No bed assigned</option>
                            <?php foreach ($beds as $bed): ?>
                                <option value="<?php echo h((string)$bed['id']); ?>" <?php echo (string)($bed['id']) === (string)($_POST['bed_id'] ?? '') ? 'selected' : ''; ?>>
                                    <?php echo h(($bed['room_name'] ?: 'No room') . ' | ' . $bed['bed_number'] . ' | ' . $bed['status']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="field">
                        <label for="move_in_date">Move-in date</label>
                        <input type="date" id="move_in_date" name="move_in_date" value="<?php echo h($_POST['move_in_date'] ?? ''); ?>">
                    </div>
                    <div class="field">
                        <label for="move_out_date">Move-out date</label>
                        <input type="date" id="move_out_date" name="move_out_date" value="<?php echo h($_POST['move_out_date'] ?? ''); ?>">
                    </div>
                    <div class="field">
                        <label for="status">Status</label>
                        <select id="status" name="status">
                            <option value="Active" <?php echo ($_POST['status'] ?? 'Active') === 'Active' ? 'selected' : ''; ?>>Active</option>
                            <option value="Inactive" <?php echo ($_POST['status'] ?? '') === 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="field">
                        <label for="payment_type">Payment type</label>
                        <select id="payment_type" name="payment_type">
                            <option value="Monthly" <?php echo ($_POST['payment_type'] ?? 'Monthly') === 'Monthly' ? 'selected' : ''; ?>>Monthly</option>
                            <option value="Weekly" <?php echo ($_POST['payment_type'] ?? '') === 'Weekly' ? 'selected' : ''; ?>>Weekly</option>
                            <option value="Daily" <?php echo ($_POST['payment_type'] ?? '') === 'Daily' ? 'selected' : ''; ?>>Daily</option>
                            <option value="Custom" <?php echo ($_POST['payment_type'] ?? '') === 'Custom' ? 'selected' : ''; ?>>Custom</option>
                        </select>
                    </div>
                    <div class="field full">
                        <label for="address">Address</label>
                        <textarea id="address" name="address"><?php echo h($_POST['address'] ?? ''); ?></textarea>
                    </div>
                    <div class="field">
                        <label for="emergency_contact">Emergency contact</label>
                        <input type="text" id="emergency_contact" name="emergency_contact" value="<?php echo h($_POST['emergency_contact'] ?? ''); ?>">
                    </div>
                    <div class="field full">
                        <label for="notes">Notes</label>
                        <textarea id="notes" name="notes"><?php echo h($_POST['notes'] ?? ''); ?></textarea>
                    </div>
                </div>
                <div class="actions">
                    <button class="button" type="submit">Create Tenant</button>
                    <a class="button secondary" href="viewtenant.php">View Tenant Records</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
