<?php
require_once __DIR__ . '/../bedspace_auth.php';

bs_require_staff();

$tenantsTable = bs_table('tenants');
$tenantId = (int)($_GET['tenant_id'] ?? 0);

if ($tenantId > 0) {
    $stmt = $conn->prepare("DELETE FROM {$tenantsTable} WHERE id = ?");
    $stmt->bind_param('i', $tenantId);
    $stmt->execute();
    $stmt->close();
}

header('Location: viewtenant.php');
exit();
