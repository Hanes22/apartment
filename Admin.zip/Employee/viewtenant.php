<?php
require_once __DIR__ . '/../bedspace_auth.php';

bs_require_staff();

$tenantsTable = bs_table('tenants');
$bedsTable = bs_table('beds');
$roomsTable = bs_table('rooms');

$tenantResult = $conn->query(
    "SELECT t.*, b.bed_number, r.name AS room_name
     FROM {$tenantsTable} t
     LEFT JOIN {$bedsTable} b ON b.id = t.bed_id
     LEFT JOIN {$roomsTable} r ON r.id = b.room_id
     ORDER BY t.created_at DESC, t.name"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenant Records</title>
    <style>
        body { margin: 0; font-family: "Inter", Arial, sans-serif; background: #f8fafc; color: #0f172a; padding: 28px; }
        .wrap { max-width: 1200px; margin: 0 auto; }
        .topbar { display: flex; justify-content: space-between; align-items: center; gap: 16px; margin-bottom: 24px; }
        .topbar h1 { margin: 0; font-size: 32px; }
        .topbar p { margin: 8px 0 0; color: #64748b; }
        .badge, .button { display:inline-flex; align-items:center; justify-content:center; padding:12px 16px; border-radius:14px; text-decoration:none; font-weight:700; }
        .badge { background:#eff6ff; color:#1d4ed8; }
        .button { background:linear-gradient(135deg, #3d8ef0, #1d4ed8); color:#fff; }
        .button.secondary { background:#e2e8f0; color:#0f172a; }
        .table-wrap { background:#fff; border:1px solid #e2e8f0; border-radius:24px; box-shadow:0 12px 28px rgba(15,23,42,.05); overflow:auto; }
        table { width:100%; border-collapse:collapse; min-width:1000px; }
        th, td { padding:14px 16px; border-bottom:1px solid #e2e8f0; text-align:left; vertical-align:top; }
        th { background:#f8fafc; font-size:12px; text-transform:uppercase; letter-spacing:.08em; color:#64748b; }
        td strong { display:block; margin-bottom:4px; }
        .actions { display:flex; gap:10px; flex-wrap:wrap; }
        .action-link { padding:10px 14px; border-radius:12px; font-weight:700; text-decoration:none; }
        .edit { background:#dbeafe; color:#1d4ed8; }
        .delete { background:#fee2e2; color:#b91c1c; }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="topbar">
            <div>
                <h1>Tenant Records</h1>
                <p>Live tenant data from the BedSpacer tenant table.</p>
            </div>
            <div style="display:flex; gap:12px; flex-wrap:wrap;">
                <a class="badge" href="createtenant.php">Create Tenant</a>
                <a class="badge" href="empdashboard.php">Employee Dashboard</a>
            </div>
        </div>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Tenant</th>
                        <th>Contact</th>
                        <th>Room / Bed</th>
                        <th>Move In</th>
                        <th>Status</th>
                        <th>Payment</th>
                        <th>Login</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($tenantResult && $tenantResult->num_rows > 0): ?>
                        <?php while ($row = $tenantResult->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <strong><?php echo h($row['name']); ?></strong>
                                    <span><?php echo h($row['email'] ?: 'No email'); ?></span>
                                </td>
                                <td>
                                    <strong><?php echo h($row['contact'] ?: 'No contact'); ?></strong>
                                    <span><?php echo h($row['emergency_contact'] ?: 'No emergency contact'); ?></span>
                                </td>
                                <td>
                                    <strong><?php echo h($row['room_name'] ?: 'No room'); ?></strong>
                                    <span><?php echo h($row['bed_number'] ?: 'No bed assigned'); ?></span>
                                </td>
                                <td>
                                    <strong><?php echo h((string)($row['move_in_date'] ?: 'Not set')); ?></strong>
                                    <span><?php echo h((string)($row['move_out_date'] ?: 'Open-ended')); ?></span>
                                </td>
                                <td>
                                    <strong><?php echo h($row['status']); ?></strong>
                                    <span><?php echo h($row['id_number'] ?: 'No ID number'); ?></span>
                                </td>
                                <td>
                                    <strong><?php echo h($row['payment_type']); ?></strong>
                                    <span><?php echo h($row['notes'] ?: 'No notes'); ?></span>
                                </td>
                                <td>
                                    <strong><?php echo h($row['username'] ?: 'No username'); ?></strong>
                                    <span><?php echo !empty($row['password_hash']) ? 'Password set' : 'No password'; ?></span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <a class="action-link edit" href="edit_tenant.php?tenant_id=<?php echo h((string)$row['id']); ?>">Edit</a>
                                        <a class="action-link delete" href="delete_tenant.php?tenant_id=<?php echo h((string)$row['id']); ?>" onclick="return confirm('Delete this tenant?');">Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8">No tenants found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
