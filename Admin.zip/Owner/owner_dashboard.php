<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BedSpace Owner Dashboard</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --navy: #0f172a;
      --surface: #f8fafc;
      --panel: #ffffff;
      --line: #e2e8f0;
      --text: #0f172a;
      --muted: #64748b;
      --primary: #3d8ef0;
      --purple: #6366f1;
      --green: #22c55e;
    }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: "Inter", sans-serif; background: var(--surface); color: var(--text); }
    a { text-decoration: none; color: inherit; }
    .wrap { width: min(1180px, calc(100% - 32px)); margin: 0 auto; padding: 28px 0 56px; }
    .topbar {
      display: flex; justify-content: space-between; align-items: center; gap: 16px;
      margin-bottom: 24px;
    }
    .brand { display: flex; gap: 14px; align-items: center; }
    .mark {
      width: 50px; height: 50px; border-radius: 16px; display: grid; place-items: center;
      background: linear-gradient(135deg, var(--primary), var(--purple)); color: #fff; font-size: 24px;
      box-shadow: 0 18px 36px rgba(61,142,240,.24);
    }
    .brand strong { display: block; font-size: 22px; letter-spacing: -.03em; }
    .brand span { display: block; color: var(--muted); font-size: 12px; text-transform: uppercase; letter-spacing: .08em; }
    .logout {
      padding: 12px 18px; border-radius: 999px; background: #fee2e2; color: #b91c1c;
      font-size: 14px; font-weight: 800;
    }
    .hero {
      background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%);
      color: #fff;
      border-radius: 28px;
      padding: 28px;
      display: grid;
      grid-template-columns: 1.05fr .95fr;
      gap: 18px;
      box-shadow: 0 24px 50px rgba(15,23,42,.16);
      margin-bottom: 22px;
    }
    .hero h1 { margin: 0 0 10px; font-size: clamp(34px, 5vw, 54px); line-height: .98; letter-spacing: -.05em; }
    .hero p { margin: 0 0 20px; color: rgba(255,255,255,.80); line-height: 1.75; }
    .stats { display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 12px; }
    .stat {
      padding: 16px; border-radius: 18px; background: rgba(255,255,255,.08);
      border: 1px solid rgba(255,255,255,.10);
    }
    .stat strong { display: block; font-size: 24px; margin-bottom: 4px; }
    .stat span { font-size: 12px; color: rgba(255,255,255,.72); }
    .hero-side {
      background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.10);
      border-radius: 22px; padding: 20px;
    }
    .hero-side h3 { margin: 0 0 14px; font-size: 18px; }
    .focus-list { display: grid; gap: 10px; }
    .focus {
      padding: 14px 16px; border-radius: 16px; background: rgba(255,255,255,.06);
    }
    .focus strong { display: block; margin-bottom: 4px; font-size: 14px; }
    .focus span { color: rgba(255,255,255,.74); font-size: 12px; line-height: 1.55; }
    .grid { display: grid; grid-template-columns: repeat(5, minmax(0,1fr)); gap: 16px; margin-bottom: 22px; }
    .card, .panel {
      background: var(--panel); border: 1px solid var(--line); border-radius: 24px;
      box-shadow: 0 14px 32px rgba(15,23,42,.06);
    }
    .card { padding: 22px; }
    .icon {
      width: 50px; height: 50px; border-radius: 16px; display: grid; place-items: center;
      background: linear-gradient(135deg, #eff6ff, #dbeafe); color: #1d4ed8; font-size: 22px; margin-bottom: 14px;
    }
    .card h3 { margin: 0 0 8px; font-size: 17px; letter-spacing: -.03em; }
    .card p { margin: 0 0 16px; color: var(--muted); font-size: 13px; line-height: 1.7; }
    .card a {
      display: inline-flex; padding: 10px 14px; border-radius: 999px;
      background: #eff6ff; color: #1d4ed8; font-size: 12px; font-weight: 800;
    }
    .lower { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
    .panel { padding: 24px; }
    .panel h3 { margin: 0 0 16px; font-size: 20px; letter-spacing: -.03em; }
    .panel p { margin: 0; color: var(--muted); line-height: 1.75; font-size: 14px; }
    .steps { display: grid; gap: 12px; }
    .step {
      display: flex; gap: 12px; padding: 14px 16px; border-radius: 16px;
      background: #f8fafc; border: 1px solid var(--line);
    }
    .step strong { display: block; margin-bottom: 4px; font-size: 14px; }
    .step span { color: var(--muted); font-size: 12px; line-height: 1.6; }
    @media (max-width: 1120px) { .grid { grid-template-columns: repeat(2, minmax(0,1fr)); } .lower, .hero { grid-template-columns: 1fr; } }
    @media (max-width: 720px) { .topbar { flex-direction: column; align-items: start; } .stats, .grid { grid-template-columns: 1fr; } }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="topbar">
      <div class="brand">
        <div class="mark">🏢</div>
        <div>
          <strong>BedSpace Owner Console</strong>
          <span>Rooms, staff, and collections</span>
        </div>
      </div>
      <a class="logout" href="../index.html">Logout</a>
    </div>

    <section class="hero">
      <div>
        <h1>Oversee rooms, staff, and collections with a cleaner owner workspace.</h1>
        <p>
          This dashboard now follows the BedSpacer direction more closely, replacing the plain link list
          with a more structured operations view for property owners and managers.
        </p>
        <div class="stats">
          <div class="stat">
            <strong>Rooms</strong>
            <span>Review room-level occupancy and related pages.</span>
          </div>
          <div class="stat">
            <strong>Staff</strong>
            <span>Open employee pages and role-management actions.</span>
          </div>
          <div class="stat">
            <strong>Fees</strong>
            <span>Monitor payment-related screens and records.</span>
          </div>
        </div>
      </div>
      <div class="hero-side">
        <h3>Owner priorities</h3>
        <div class="focus-list">
          <div class="focus">
            <strong>Monitor rooms</strong>
            <span>Check room summaries and occupancy-related records.</span>
          </div>
          <div class="focus">
            <strong>Coordinate staff</strong>
            <span>Review employees and create new support personnel when needed.</span>
          </div>
          <div class="focus">
            <strong>Track payments and complaints</strong>
            <span>Keep revenue and issue visibility close to operational pages.</span>
          </div>
        </div>
      </div>
    </section>

    <section class="grid">
      <article class="card">
        <div class="icon">👥</div>
        <h3>View Employees</h3>
        <p>Inspect current employee records and open staff actions.</p>
        <a href="viewempl.php">Open staff</a>
      </article>
      <article class="card">
        <div class="icon">📈</div>
        <h3>Count Statistics</h3>
        <p>Review current statistics and overall system counts.</p>
        <a href="complaintcount.php">View stats</a>
      </article>
      <article class="card">
        <div class="icon">➕</div>
        <h3>Create Employee</h3>
        <p>Add new staff to support your BedSpace operations workflow.</p>
        <a href="createemployee.php">Create staff</a>
      </article>
      <article class="card">
        <div class="icon">🛏</div>
        <h3>Room Details</h3>
        <p>Inspect room information and occupancy-related details.</p>
        <a href="roomdetails.php">View rooms</a>
      </article>
      <article class="card">
        <div class="icon">💳</div>
        <h3>Fees Received</h3>
        <p>Open payment records and view maintenance-related collections.</p>
        <a href="feesrecieved.php">Open fees</a>
      </article>
    </section>

    <section class="lower">
      <article class="panel">
        <h3>How this owner screen is improved</h3>
        <p>
          The page now feels closer to the BedSpacer product language: stronger hierarchy, better spacing,
          cleaner task cards, and more focus on rooms, beds, staff, and collections instead of plain utility links.
        </p>
      </article>
      <article class="panel">
        <h3>Suggested next enhancements</h3>
        <div class="steps">
          <div class="step">
            <div>1</div>
            <div>
              <strong>Restyle staff and room tables</strong>
              <span>Bring the same BedSpacer visuals into detail pages and CRUD screens.</span>
            </div>
          </div>
          <div class="step">
            <div>2</div>
            <div>
              <strong>Map true bedspace occupancy</strong>
              <span>Align the data model more directly with rooms, beds, and active tenants.</span>
            </div>
          </div>
          <div class="step">
            <div>3</div>
            <div>
              <strong>Upgrade forms and reports</strong>
              <span>Make payment, complaints, and maintenance pages feel like one consistent app.</span>
            </div>
          </div>
        </div>
      </article>
    </section>
  </div>
</body>
</html>
