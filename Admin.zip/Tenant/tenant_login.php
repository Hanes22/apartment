<?php
require_once __DIR__ . '/../bedspace_auth.php';

bs_ensure_schema($conn);
bs_auth_start();

if (($_SESSION['bedspace_role'] ?? '') === 'tenant') {
    header('Location: tenant_dashboard.php');
    exit();
}

$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');
    $tenantsTable = bs_table('tenants');

    $stmt = $conn->prepare("SELECT * FROM {$tenantsTable} WHERE username = ? AND status = 'Active' LIMIT 1");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $tenant = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($tenant && bs_password_verify_value($password, $tenant['password_hash'] ?? '')) {
        bs_login_tenant($tenant);
        $update = $conn->prepare("UPDATE {$tenantsTable} SET last_login = NOW() WHERE id = ?");
        $update->bind_param('i', $tenant['id']);
        $update->execute();
        $update->close();
        header('Location: tenant_dashboard.php');
        exit();
    }

    $errorMessage = 'Invalid tenant username or password.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenant Login</title>
    <style>
        body { margin:0; min-height:100vh; font-family:"Inter", Arial, sans-serif; background:linear-gradient(135deg,#0f172a 0%,#17263a 45%,#1e293b 100%); display:grid; place-items:center; padding:24px; }
        .card { width:min(460px,100%); background:rgba(248,250,252,.96); border-radius:28px; padding:32px; box-shadow:0 28px 64px rgba(15,23,42,.35); }
        h1 { margin:0 0 10px; font-size:34px; }
        p { margin:0 0 22px; color:#64748b; line-height:1.7; }
        label { display:block; margin-bottom:8px; font-size:13px; font-weight:700; color:#334155; }
        input { width:100%; border-radius:14px; border:1px solid #cbd5e1; padding:13px 14px; font:inherit; font-size:14px; margin-bottom:16px; }
        button, .link { display:inline-flex; align-items:center; justify-content:center; padding:14px 16px; border-radius:14px; font-weight:700; text-decoration:none; }
        button { width:100%; border:none; cursor:pointer; background:linear-gradient(135deg,#22c55e,#16a34a); color:#fff; }
        .notice { padding:14px 16px; border-radius:14px; margin-bottom:16px; background:#fef2f2; color:#b91c1c; border:1px solid #fecaca; }
        .actions { display:flex; gap:12px; margin-top:16px; flex-wrap:wrap; }
        .link { background:#e2e8f0; color:#0f172a; }
    </style>
</head>
<body>
    <form class="card" method="post">
        <h1>Tenant Login</h1>
        <p>Access only your room, payment, and maintenance information.</p>

        <?php if ($errorMessage !== ''): ?>
            <div class="notice"><?php echo h($errorMessage); ?></div>
        <?php endif; ?>

        <label for="username">Username</label>
        <input type="text" id="username" name="username" required>

        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">Login</button>

        <div class="actions">
            <a class="link" href="../login.html">Back</a>
        </div>
    </form>
</body>
</html>
