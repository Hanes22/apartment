<?php
require_once __DIR__ . '/../bedspace_auth.php';

bs_require_tenant();
bs_ensure_schema($conn);

$tenantId = (int)($_SESSION['bedspace_tenant_id'] ?? 0);
$tenantsTable = bs_table('tenants');
$bedsTable = bs_table('beds');
$roomsTable = bs_table('rooms');
$paymentsTable = bs_table('payments');
$maintenanceTable = bs_table('maintenance');

$stmt = $conn->prepare(
    "SELECT t.*, b.bed_number, b.type AS bed_type, r.name AS room_name, r.room_type, r.pricing_mode
     FROM {$tenantsTable} t
     LEFT JOIN {$bedsTable} b ON b.id = t.bed_id
     LEFT JOIN {$roomsTable} r ON r.id = b.room_id
     WHERE t.id = ?
     LIMIT 1"
);
$stmt->bind_param('i', $tenantId);
$stmt->execute();
$tenant = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$tenant) {
    bs_logout();
    header('Location: tenant_login.php');
    exit();
}

$payments = [];
$paymentStmt = $conn->prepare("SELECT * FROM {$paymentsTable} WHERE tenant_id = ? ORDER BY due_date DESC");
$paymentStmt->bind_param('i', $tenantId);
$paymentStmt->execute();
$paymentResult = $paymentStmt->get_result();
while ($row = $paymentResult->fetch_assoc()) {
    $payments[] = $row;
}
$paymentStmt->close();

$maintenance = [];
$maintStmt = $conn->prepare("SELECT * FROM {$maintenanceTable} WHERE tenant_id = ? ORDER BY date_submitted DESC");
$maintStmt->bind_param('i', $tenantId);
$maintStmt->execute();
$maintResult = $maintStmt->get_result();
while ($row = $maintResult->fetch_assoc()) {
    $maintenance[] = $row;
}
$maintStmt->close();

$currency = bs_currency($conn);
$totalDue = array_sum(array_map(fn($item) => (float)$item['amount_due'], $payments));
$totalPaid = array_sum(array_map(fn($item) => (float)$item['amount_paid'], $payments));
$openIssues = count(array_filter($maintenance, fn($item) => ($item['status'] ?? '') !== 'Fixed'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenant Dashboard</title>
    <style>
        body { margin:0; font-family:"Inter", Arial, sans-serif; background:#f8fafc; color:#0f172a; }
        .wrap { width:min(1180px,calc(100% - 28px)); margin:0 auto; padding:32px 0 56px; }
        .topbar { display:flex; justify-content:space-between; align-items:center; gap:16px; margin-bottom:22px; }
        .brand strong { display:block; font-size:26px; }
        .brand span { color:#64748b; font-size:13px; }
        .logout { padding:12px 18px; border-radius:999px; background:#e2e8f0; color:#0f172a; font-size:14px; font-weight:700; text-decoration:none; }
        .hero, .grid, .footer { display:grid; gap:18px; }
        .hero { grid-template-columns:1.05fr .95fr; margin-bottom:18px; }
        .panel, .card { background:#fff; border:1px solid #e2e8f0; border-radius:24px; box-shadow:0 14px 32px rgba(15,23,42,.08); }
        .panel { padding:24px; }
        .hero-main h1 { margin:0 0 10px; font-size:42px; line-height:1; }
        .hero-main p { margin:0 0 18px; color:#64748b; line-height:1.7; }
        .pill { display:inline-flex; padding:10px 14px; border-radius:999px; background:#eff6ff; color:#1d4ed8; font-size:12px; font-weight:800; margin-bottom:14px; }
        .stats { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:12px; }
        .stat { padding:16px; border-radius:18px; background:#f8fafc; border:1px solid #e2e8f0; }
        .stat strong { display:block; font-size:24px; margin-bottom:4px; }
        .stat span { font-size:12px; color:#64748b; }
        .grid { grid-template-columns:repeat(3,minmax(0,1fr)); margin-bottom:18px; }
        .card { padding:22px; }
        .card h3 { margin:0 0 8px; font-size:18px; }
        .card p { margin:0; color:#64748b; line-height:1.7; font-size:14px; }
        .footer { grid-template-columns:1fr 1fr; }
        .list { display:grid; gap:12px; }
        .item { padding:14px 16px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:16px; }
        .item strong { display:block; margin-bottom:4px; }
        .item span { color:#64748b; font-size:13px; line-height:1.6; }
        @media (max-width:960px) { .hero, .grid, .footer, .stats { grid-template-columns:1fr; } .topbar { flex-direction:column; align-items:flex-start; } }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="topbar">
            <div class="brand">
                <strong><?php echo h($tenant['name']); ?></strong>
                <span>Tenant Dashboard</span>
            </div>
            <a class="logout" href="../logout.php">Logout</a>
        </div>

        <section class="hero">
            <article class="panel hero-main">
                <div class="pill">Tenant Access</div>
                <h1>Your BedSpace Portal</h1>
                <p>Only your room, payment, and maintenance information appears here.</p>
                <div class="stats">
                    <div class="stat">
                        <strong><?php echo h($tenant['room_name'] ?: 'No room'); ?></strong>
                        <span>Assigned room</span>
                    </div>
                    <div class="stat">
                        <strong><?php echo h($tenant['bed_number'] ?: 'No bed'); ?></strong>
                        <span>Assigned bed</span>
                    </div>
                    <div class="stat">
                        <strong><?php echo h($tenant['payment_type'] ?: 'Monthly'); ?></strong>
                        <span>Billing cycle</span>
                    </div>
                </div>
            </article>

            <article class="panel">
                <h3 style="margin-top:0;">Profile</h3>
                <div class="list">
                    <div class="item"><strong>Contact</strong><span><?php echo h($tenant['contact'] ?: 'Not set'); ?></span></div>
                    <div class="item"><strong>Email</strong><span><?php echo h($tenant['email'] ?: 'Not set'); ?></span></div>
                    <div class="item"><strong>Status</strong><span><?php echo h($tenant['status']); ?></span></div>
                </div>
            </article>
        </section>

        <section class="grid">
            <article class="card">
                <h3>Room</h3>
                <p><?php echo h($tenant['room_name'] ?: 'No room assigned'); ?></p>
                <p><?php echo h(($tenant['room_type'] ?: 'Room') . ' | ' . ($tenant['pricing_mode'] ?: 'Per Bed')); ?></p>
            </article>
            <article class="card">
                <h3>Payments</h3>
                <p>Total due: <?php echo h($currency . number_format($totalDue, 2)); ?></p>
                <p>Total paid: <?php echo h($currency . number_format($totalPaid, 2)); ?></p>
            </article>
            <article class="card">
                <h3>Maintenance</h3>
                <p><?php echo h((string)$openIssues); ?> open issue(s)</p>
                <p><?php echo h((string)count($maintenance)); ?> total ticket(s)</p>
            </article>
        </section>

        <section class="footer">
            <article class="panel">
                <h3 style="margin-top:0;">Payment Records</h3>
                <div class="list">
                    <?php if ($payments): ?>
                        <?php foreach (array_slice($payments, 0, 5) as $payment): ?>
                            <div class="item">
                                <strong><?php echo h($payment['payment_type']); ?> | <?php echo h($payment['status']); ?></strong>
                                <span>Due: <?php echo h((string)$payment['due_date']); ?> | Amount: <?php echo h($currency . number_format((float)$payment['amount_due'], 2)); ?></span>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="item"><span>No payment records found.</span></div>
                    <?php endif; ?>
                </div>
            </article>

            <article class="panel">
                <h3 style="margin-top:0;">Maintenance Records</h3>
                <div class="list">
                    <?php if ($maintenance): ?>
                        <?php foreach (array_slice($maintenance, 0, 5) as $issue): ?>
                            <div class="item">
                                <strong><?php echo h($issue['category'] ?: 'General'); ?> | <?php echo h($issue['status']); ?></strong>
                                <span><?php echo h($issue['issue']); ?></span>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="item"><span>No maintenance records found.</span></div>
                    <?php endif; ?>
                </div>
            </article>
        </section>
    </div>
</body>
</html>
