<?php
// Database configuration
$servername = "localhost";
$username = "ngkbhmpg_moduser";
$password = "Hanes@1998";
$database = "ngkbhmpg_modmenu";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>
