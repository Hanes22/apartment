<?php
require_once __DIR__ . '/bedspace_auth.php';

bs_logout();
header('Location: login.html');
exit();
