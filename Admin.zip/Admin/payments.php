<?php
require_once __DIR__ . '/../bedspace_bootstrap.php';
require_once __DIR__ . '/bedspace_layout.php';

bs_ensure_schema($conn);

$paymentsTable = bs_table('payments');
$tenantsTable = bs_table('tenants');
$bedsTable = bs_table('beds');
$roomsTable = bs_table('rooms');
$message = '';
$currency = bs_currency($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_bill') {
        $tenantId = (int)($_POST['tenant_id'] ?? 0);
        $amountDue = (float)($_POST['amount_due'] ?? 0);
        $paymentType = $_POST['payment_type'] ?? 'Monthly';
        $dueDate = $_POST['due_date'] ?? date('Y-m-d', strtotime('+30 days'));
        $notes = trim($_POST['notes'] ?? '');
        $paymentMethod = $_POST['payment_method'] ?? null;
        $paymentChannel = $_POST['payment_channel'] ?? null;
        $transactionReference = trim($_POST['transaction_reference'] ?? '');

        if ($tenantId > 0 && $amountDue > 0) {
            $stmt = $conn->prepare(
                "INSERT INTO {$paymentsTable}
                 (tenant_id, amount_due, amount_paid, payment_type, due_date, status, notes, payment_method, payment_channel, transaction_reference)
                 VALUES (?, ?, 0, ?, ?, 'Pending', ?, ?, ?, ?)"
            );
            $stmt->bind_param(
                'idssssss',
                $tenantId,
                $amountDue,
                $paymentType,
                $dueDate,
                $notes,
                $paymentMethod,
                $paymentChannel,
                $transactionReference
            );
            $stmt->execute();
            $stmt->close();
            $message = 'Billing entry created.';
        }
    }

    if ($action === 'record_payment') {
        $paymentId = (int)($_POST['payment_id'] ?? 0);
        $additionalPaid = (float)($_POST['amount_paid'] ?? 0);
        $paymentMethod = $_POST['payment_method'] ?? null;
        $paymentChannel = $_POST['payment_channel'] ?? null;
        $transactionReference = trim($_POST['transaction_reference'] ?? '');
        $notes = trim($_POST['notes'] ?? '');

        if ($paymentId > 0 && $additionalPaid > 0) {
            $stmt = $conn->prepare("SELECT amount_due, amount_paid, notes FROM {$paymentsTable} WHERE id = ?");
            $stmt->bind_param('i', $paymentId);
            $stmt->execute();
            $result = $stmt->get_result();
            $payment = $result->fetch_assoc();
            $stmt->close();

            if ($payment) {
                $newPaid = (float)$payment['amount_paid'] + $additionalPaid;
                $status = 'Partial';
                if ($newPaid >= (float)$payment['amount_due']) {
                    $status = 'Paid';
                }

                $receipt = 'RCP-' . strtoupper(substr(uniqid(), -6));
                $mergedNotes = $notes !== '' ? $notes : (string)$payment['notes'];
                $stmt = $conn->prepare(
                    "UPDATE {$paymentsTable}
                     SET amount_paid=?, status=?, paid_date=NOW(), receipt_number=?, notes=?, payment_method=?, payment_channel=?, transaction_reference=?
                     WHERE id=?"
                );
                $stmt->bind_param(
                    'dssssssi',
                    $newPaid,
                    $status,
                    $receipt,
                    $mergedNotes,
                    $paymentMethod,
                    $paymentChannel,
                    $transactionReference,
                    $paymentId
                );
                $stmt->execute();
                $stmt->close();
                $message = 'Payment recorded.';
            }
        }
    }

    if ($action === 'mark_overdue') {
        $conn->query("UPDATE {$paymentsTable} SET status='Overdue' WHERE status='Pending' AND due_date < CURDATE()");
        $message = 'Overdue payments updated.';
    }

    if ($action === 'delete_payment') {
        $paymentId = (int)($_POST['payment_id'] ?? 0);
        if ($paymentId > 0) {
            $stmt = $conn->prepare("DELETE FROM {$paymentsTable} WHERE id = ?");
            $stmt->bind_param('i', $paymentId);
            $stmt->execute();
            $stmt->close();
            $message = 'Payment record deleted.';
        }
    }
}

$tenants = $conn->query(
    "SELECT t.id, t.name, t.payment_type, b.bed_number, r.name AS room_name
     FROM {$tenantsTable} t
     LEFT JOIN {$bedsTable} b ON b.id = t.bed_id
     LEFT JOIN {$roomsTable} r ON r.id = b.room_id
     ORDER BY t.name"
)->fetch_all(MYSQLI_ASSOC);

$payments = $conn->query(
    "SELECT p.*, t.name AS tenant_name, t.contact, b.bed_number, r.name AS room_name
     FROM {$paymentsTable} p
     JOIN {$tenantsTable} t ON t.id = p.tenant_id
     LEFT JOIN {$bedsTable} b ON b.id = t.bed_id
     LEFT JOIN {$roomsTable} r ON r.id = b.room_id
     ORDER BY p.due_date DESC, p.created_at DESC"
)->fetch_all(MYSQLI_ASSOC);

$totalDue = array_sum(array_map(fn($item) => (float)$item['amount_due'], $payments));
$totalPaid = array_sum(array_map(fn($item) => (float)$item['amount_paid'], $payments));
$totalOutstanding = max($totalDue - $totalPaid, 0);
$collectedThisMonth = 0.0;
$statusTotals = ['Paid' => 0, 'Partial' => 0, 'Pending' => 0, 'Overdue' => 0];
$methodTotals = [];
$monthlyTotals = [];

for ($i = 5; $i >= 0; $i--) {
    $key = date('Y-m', strtotime("-{$i} months"));
    $monthlyTotals[$key] = 0.0;
}

foreach ($payments as $payment) {
    $status = (string)($payment['status'] ?? 'Pending');
    if (!isset($statusTotals[$status])) {
        $statusTotals[$status] = 0;
    }
    $statusTotals[$status]++;

    $method = trim((string)($payment['payment_method'] ?? ''));
    if ($method === '') {
        $method = 'Unspecified';
    }
    if (!isset($methodTotals[$method])) {
        $methodTotals[$method] = 0.0;
    }
    $methodTotals[$method] += (float)$payment['amount_paid'];

    $paidDate = (string)($payment['paid_date'] ?? '');
    if ($paidDate !== '') {
        $monthKey = date('Y-m', strtotime($paidDate));
        if (isset($monthlyTotals[$monthKey])) {
            $monthlyTotals[$monthKey] += (float)$payment['amount_paid'];
        }
        if (date('Y-m', strtotime($paidDate)) === date('Y-m')) {
            $collectedThisMonth += (float)$payment['amount_paid'];
        }
    }
}

$maxStatus = max(1, max($statusTotals));
$maxMethod = max(1, (float)max($methodTotals ?: ['Unspecified' => 0]));
$maxMonthly = max(1, (float)max($monthlyTotals));

bs_admin_shell_start('Payments', 'Manage billing, collections, and payment records.', 'payments');
?>

<?php if ($message !== ''): ?>
  <div class="notice"><?php echo h($message); ?></div>
<?php endif; ?>

<section class="hero">
  <div>
    <h2>Payments</h2>
    <p>Manage billing, payment methods, references, due dates, collections, and totals.</p>
    <div class="hero-stats">
      <div class="hero-stat">
        <strong><?php echo count($payments); ?></strong>
        <span>Total payment records</span>
      </div>
      <div class="hero-stat">
        <strong><?php echo count(array_filter($payments, fn($item) => $item['status'] === 'Overdue')); ?></strong>
        <span>Overdue payments</span>
      </div>
      <div class="hero-stat">
        <strong><?php echo $currency . number_format(array_sum(array_map(fn($item) => (float)$item['amount_paid'], $payments)), 2); ?></strong>
        <span>Total paid amount</span>
      </div>
    </div>
  </div>
  <div class="hero-panel">
    <h3>Methods</h3>
    <div class="stack">
      <div class="stack-item">
        <strong>GCash</strong>
        <span>Store transaction references.</span>
      </div>
      <div class="stack-item">
        <strong>Card and transfer</strong>
        <span>Record method and channel.</span>
      </div>
      <div class="stack-item">
        <strong>Overdue</strong>
        <span>Update overdue records when needed.</span>
      </div>
    </div>
  </div>
</section>

<section class="cards">
  <article class="card">
    <div class="card-label">Total Due</div>
    <strong><?php echo h($currency . number_format($totalDue, 2)); ?></strong>
    <span>All billed amounts</span>
  </article>
  <article class="card">
    <div class="card-label">Total Paid</div>
    <strong><?php echo h($currency . number_format($totalPaid, 2)); ?></strong>
    <span>All recorded collections</span>
  </article>
  <article class="card">
    <div class="card-label">Outstanding</div>
    <strong><?php echo h($currency . number_format($totalOutstanding, 2)); ?></strong>
    <span>Remaining unpaid balance</span>
  </article>
  <article class="card">
    <div class="card-label">This Month</div>
    <strong><?php echo h($currency . number_format($collectedThisMonth, 2)); ?></strong>
    <span>Collections recorded this month</span>
  </article>
</section>

<section class="chart-grid" style="margin-bottom:18px;">
  <article class="panel chart-card">
    <h3>Collections by Month</h3>
    <div class="bar-list">
      <?php foreach ($monthlyTotals as $month => $amount): ?>
        <?php $width = max(6, (int)round(($amount / $maxMonthly) * 100)); ?>
        <div class="bar-row">
          <div class="bar-head">
            <strong><?php echo h(date('M Y', strtotime($month . '-01'))); ?></strong>
            <span><?php echo h($currency . number_format($amount, 2)); ?></span>
          </div>
          <div class="bar-track"><div class="bar-fill navy" style="width: <?php echo $width; ?>%;"></div></div>
        </div>
      <?php endforeach; ?>
    </div>
  </article>

  <article class="panel chart-card">
    <h3>Payments by Method</h3>
    <div class="bar-list">
      <?php foreach ($methodTotals as $method => $amount): ?>
        <?php $width = max(6, (int)round(($amount / $maxMethod) * 100)); ?>
        <div class="bar-row">
          <div class="bar-head">
            <strong><?php echo h($method); ?></strong>
            <span><?php echo h($currency . number_format($amount, 2)); ?></span>
          </div>
          <div class="bar-track"><div class="bar-fill" style="width: <?php echo $width; ?>%;"></div></div>
        </div>
      <?php endforeach; ?>
    </div>
  </article>
</section>

<section class="chart-grid" style="margin-bottom:18px;">
  <article class="panel chart-card">
    <h3>Record Count by Status</h3>
    <div class="bar-list">
      <?php foreach ($statusTotals as $status => $count): ?>
        <?php $width = max(6, (int)round(($count / $maxStatus) * 100)); ?>
        <div class="bar-row">
          <div class="bar-head">
            <strong><?php echo h($status); ?></strong>
            <span><?php echo h((string)$count); ?></span>
          </div>
          <div class="bar-track"><div class="bar-fill warn" style="width: <?php echo $width; ?>%;"></div></div>
        </div>
      <?php endforeach; ?>
    </div>
  </article>

  <article class="panel chart-card">
    <h3>Collection Summary</h3>
    <div class="stack">
      <div class="stack-item">
        <strong>Total due</strong>
        <span><?php echo h($currency . number_format($totalDue, 2)); ?></span>
      </div>
      <div class="stack-item">
        <strong>Total paid</strong>
        <span><?php echo h($currency . number_format($totalPaid, 2)); ?></span>
      </div>
      <div class="stack-item">
        <strong>Outstanding balance</strong>
        <span><?php echo h($currency . number_format($totalOutstanding, 2)); ?></span>
      </div>
    </div>
  </article>
</section>

<section class="two-col">
  <article class="panel">
    <h3>Create billing entry</h3>
    <form class="stack-form" method="post">
      <input type="hidden" name="action" value="create_bill">
      <div class="form-grid">
        <div class="field">
          <label for="tenant_id">Tenant</label>
          <select name="tenant_id" id="tenant_id" required>
            <option value="">Select tenant</option>
            <?php foreach ($tenants as $tenant): ?>
              <option value="<?php echo h((string)$tenant['id']); ?>">
                <?php echo h($tenant['name'] . ' | ' . ($tenant['room_name'] ?: 'No room') . ' / ' . ($tenant['bed_number'] ?: 'No bed')); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label for="amount_due">Amount due</label>
          <input type="number" step="0.01" name="amount_due" id="amount_due" required>
        </div>
        <div class="field">
          <label for="payment_type">Billing cycle</label>
          <select name="payment_type" id="payment_type">
            <option value="Monthly">Monthly</option>
            <option value="Weekly">Weekly</option>
            <option value="Daily">Daily</option>
            <option value="Custom">Custom</option>
          </select>
        </div>
        <div class="field">
          <label for="due_date">Due date</label>
          <input type="date" name="due_date" id="due_date" value="<?php echo date('Y-m-d', strtotime('+30 days')); ?>">
        </div>
        <div class="field">
          <label for="payment_method">Preferred method</label>
          <select name="payment_method" id="payment_method">
            <option value="">Select method</option>
            <?php foreach (bs_payment_methods() as $method): ?>
              <option value="<?php echo h($method); ?>"><?php echo h($method); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label for="payment_channel">Payment channel</label>
          <select name="payment_channel" id="payment_channel">
            <option value="">Select channel</option>
            <?php foreach (bs_payment_channels() as $channel): ?>
              <option value="<?php echo h($channel); ?>"><?php echo h($channel); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field full">
          <label for="transaction_reference">Initial transaction reference</label>
          <input type="text" name="transaction_reference" id="transaction_reference" placeholder="Optional GCash reference / card approval code / transfer reference">
        </div>
        <div class="field full">
          <label for="notes">Billing notes</label>
          <textarea name="notes" id="notes" placeholder="Monthly private room rent, deposit top-up, shared room maintenance, etc."></textarea>
        </div>
      </div>
      <button type="submit">Create bill</button>
    </form>
  </article>

  <article class="panel">
    <h3>Record payment received</h3>
    <form class="stack-form" method="post">
      <input type="hidden" name="action" value="record_payment">
      <div class="form-grid">
        <div class="field">
          <label for="payment_id">Payment record</label>
          <select name="payment_id" id="payment_id" required>
            <option value="">Select record</option>
            <?php foreach ($payments as $payment): ?>
              <option value="<?php echo h((string)$payment['id']); ?>">
                #<?php echo h((string)$payment['id']); ?> | <?php echo h($payment['tenant_name']); ?> | <?php echo h($currency . number_format((float)$payment['amount_due'], 2)); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label for="amount_paid">Amount paid now</label>
          <input type="number" step="0.01" name="amount_paid" id="amount_paid" required>
        </div>
        <div class="field">
          <label for="record_method">Method used</label>
          <select name="payment_method" id="record_method">
            <?php foreach (bs_payment_methods() as $method): ?>
              <option value="<?php echo h($method); ?>"><?php echo h($method); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label for="record_channel">Channel</label>
          <select name="payment_channel" id="record_channel">
            <?php foreach (bs_payment_channels() as $channel): ?>
              <option value="<?php echo h($channel); ?>"><?php echo h($channel); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field full">
          <label for="record_reference">Transaction reference</label>
          <input type="text" name="transaction_reference" id="record_reference" placeholder="GCash ref / card auth / bank ref / receipt number">
        </div>
        <div class="field full">
          <label for="record_notes">Notes</label>
          <textarea name="notes" id="record_notes" placeholder="Partial payment, paid via GCash, card terminal, walk-in cash, etc."></textarea>
        </div>
      </div>
      <button type="submit">Record payment</button>
    </form>
    <form class="inline" method="post" style="margin-top:16px;">
      <input type="hidden" name="action" value="mark_overdue">
      <button type="submit" class="button secondary">Mark overdue bills</button>
    </form>
  </article>
</section>

<section class="panel" style="margin-top:18px;">
  <div class="toolbar">
    <h3 style="margin:0;">Live payment ledger</h3>
    <span class="badge"><?php echo count($payments); ?> records</span>
  </div>

  <?php if (!$payments): ?>
    <div class="empty">No payment records found yet.</div>
  <?php else: ?>
    <div class="room-card-list">
      <?php foreach ($payments as $payment): ?>
        <div class="room-card">
          <div class="room-card-image"></div>
          <div class="room-card-body">
            <div class="toolbar" style="margin:0;">
              <div>
                <h3 style="margin:0 0 8px;">Payment #<?php echo h((string)$payment['id']); ?> | <?php echo h($payment['tenant_name']); ?></h3>
                <div class="room-meta">
                  <span class="status-pill <?php echo strtolower((string)$payment['status']); ?>"><?php echo h($payment['status']); ?></span>
                  <?php if (!empty($payment['room_name'])): ?><span class="meta-pill"><?php echo h($payment['room_name']); ?></span><?php endif; ?>
                  <?php if (!empty($payment['bed_number'])): ?><span class="meta-pill"><?php echo h($payment['bed_number']); ?></span><?php endif; ?>
                  <span class="meta-pill"><?php echo h($payment['payment_type']); ?></span>
                </div>
              </div>
              <form class="inline" method="post" onsubmit="return confirm('Delete this payment record?');">
                <input type="hidden" name="action" value="delete_payment">
                <input type="hidden" name="payment_id" value="<?php echo h((string)$payment['id']); ?>">
                <button type="submit" class="button-danger">Delete</button>
              </form>
            </div>

            <div class="cards" style="grid-template-columns: repeat(3, minmax(0, 1fr)); margin:0;">
              <div class="card">
                <div class="card-label">Amount Due</div>
                <strong><?php echo h($currency . number_format((float)$payment['amount_due'], 2)); ?></strong>
                <span>Billing value</span>
              </div>
              <div class="card">
                <div class="card-label">Amount Paid</div>
                <strong><?php echo h($currency . number_format((float)$payment['amount_paid'], 2)); ?></strong>
                <span>Received so far</span>
              </div>
              <div class="card">
                <div class="card-label">Due Date</div>
                <strong><?php echo h((string)$payment['due_date']); ?></strong>
                <span>Scheduled due</span>
              </div>
            </div>

            <div class="table-shell">
              <div class="table-row">
                <div>
                  <strong>Payment method</strong>
                  <span><?php echo h($payment['payment_method'] ?: 'Not set'); ?></span>
                </div>
                <div>
                  <strong>Channel</strong>
                  <span><?php echo h($payment['payment_channel'] ?: 'Not set'); ?></span>
                </div>
                <div>
                  <strong>Reference</strong>
                  <span><?php echo h($payment['transaction_reference'] ?: ($payment['receipt_number'] ?: 'None')); ?></span>
                </div>
                <div>
                  <strong>Contact</strong>
                  <span><?php echo h($payment['contact'] ?: 'N/A'); ?></span>
                </div>
                <div>
                  <strong>Paid Date</strong>
                  <span><?php echo h((string)($payment['paid_date'] ?: 'Unpaid')); ?></span>
                </div>
                <div>
                  <strong>Notes</strong>
                  <span><?php echo h((string)($payment['notes'] ?: 'No notes')); ?></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>

<?php
bs_admin_shell_end();
