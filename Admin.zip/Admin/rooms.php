<?php
require_once __DIR__ . '/../bedspace_bootstrap.php';
require_once __DIR__ . '/bedspace_layout.php';

bs_ensure_schema($conn);

$roomsTable = bs_table('rooms');
$bedsTable = bs_table('beds');
$message = '';
$roomForm = [
    'room_id' => 0,
    'name' => '',
    'description' => '',
    'floor' => 1,
    'room_type' => 'Shared',
    'pricing_mode' => 'Per Bed',
    'capacity' => 4,
    'monthly_rate' => '',
    'weekly_rate' => '',
    'daily_rate' => '',
    'amenities' => '',
    'is_active' => 1,
    'image_path' => '',
];
$bedForm = [
    'bed_id' => 0,
    'room_id' => '',
    'bed_number' => '',
    'type' => 'Single',
    'status' => 'Available',
    'price' => '',
    'notes' => '',
    'image_path' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save_room') {
        $roomId = (int)($_POST['room_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $floor = (int)($_POST['floor'] ?? 1);
        $roomType = $_POST['room_type'] ?? 'Shared';
        $pricingMode = $_POST['pricing_mode'] ?? 'Per Bed';
        $capacity = (int)($_POST['capacity'] ?? 4);
        $monthlyRate = (float)($_POST['monthly_rate'] ?? 0);
        $weeklyRate = (float)($_POST['weekly_rate'] ?? 0);
        $dailyRate = (float)($_POST['daily_rate'] ?? 0);
        $amenities = trim($_POST['amenities'] ?? '');
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $existingImage = $_POST['existing_image_path'] ?? null;
        $imagePath = bs_handle_image_upload('room_image', 'rooms', $existingImage);

        if ($name !== '') {
            if ($roomId > 0) {
                $stmt = $conn->prepare(
                    "UPDATE {$roomsTable}
                     SET name=?, description=?, floor=?, room_type=?, capacity=?, monthly_rate=?, weekly_rate=?, daily_rate=?, pricing_mode=?, amenities=?, is_active=?, image_path=?
                     WHERE id=?"
                );
                $stmt->bind_param(
                    'ssisidddssisi',
                    $name,
                    $description,
                    $floor,
                    $roomType,
                    $capacity,
                    $monthlyRate,
                    $weeklyRate,
                    $dailyRate,
                    $pricingMode,
                    $amenities,
                    $isActive,
                    $imagePath,
                    $roomId
                );
                $stmt->execute();
                $stmt->close();
                $message = 'Room updated successfully.';
            } else {
                $stmt = $conn->prepare(
                    "INSERT INTO {$roomsTable}
                     (name, description, floor, room_type, capacity, monthly_rate, weekly_rate, daily_rate, pricing_mode, amenities, is_active, image_path)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );
                $stmt->bind_param(
                    'ssisidddssis',
                    $name,
                    $description,
                    $floor,
                    $roomType,
                    $capacity,
                    $monthlyRate,
                    $weeklyRate,
                    $dailyRate,
                    $pricingMode,
                    $amenities,
                    $isActive,
                    $imagePath
                );
                $stmt->execute();
                $stmt->close();
                $message = 'Room created successfully.';
            }
        }
    }

    if ($action === 'delete_room') {
        $roomId = (int)($_POST['room_id'] ?? 0);
        if ($roomId > 0) {
            $stmt = $conn->prepare("DELETE FROM {$bedsTable} WHERE room_id = ?");
            $stmt->bind_param('i', $roomId);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM {$roomsTable} WHERE id = ?");
            $stmt->bind_param('i', $roomId);
            $stmt->execute();
            $stmt->close();
            $message = 'Room deleted.';
        }
    }

    if ($action === 'save_bed') {
        $bedId = (int)($_POST['bed_id'] ?? 0);
        $roomId = (int)($_POST['room_id'] ?? 0);
        $bedNumber = trim($_POST['bed_number'] ?? '');
        $type = $_POST['type'] ?? 'Single';
        $status = $_POST['status'] ?? 'Available';
        $price = (float)($_POST['price'] ?? 0);
        $notes = trim($_POST['notes'] ?? '');
        $existingImage = $_POST['existing_image_path'] ?? null;
        $imagePath = bs_handle_image_upload('bed_image', 'beds', $existingImage);

        if ($roomId > 0 && $bedNumber !== '') {
            if ($bedId > 0) {
                $stmt = $conn->prepare(
                    "UPDATE {$bedsTable}
                     SET room_id=?, bed_number=?, type=?, status=?, price=?, notes=?, image_path=?
                     WHERE id=?"
                );
                $stmt->bind_param('isssdssi', $roomId, $bedNumber, $type, $status, $price, $notes, $imagePath, $bedId);
                $stmt->execute();
                $stmt->close();
                $message = 'Bed updated successfully.';
            } else {
                $stmt = $conn->prepare(
                    "INSERT INTO {$bedsTable} (room_id, bed_number, type, status, price, notes, image_path)
                     VALUES (?, ?, ?, ?, ?, ?, ?)"
                );
                $stmt->bind_param('isssdss', $roomId, $bedNumber, $type, $status, $price, $notes, $imagePath);
                $stmt->execute();
                $stmt->close();
                $message = 'Bed added successfully.';
            }
        }
    }

    if ($action === 'delete_bed') {
        $bedId = (int)($_POST['bed_id'] ?? 0);
        if ($bedId > 0) {
            $stmt = $conn->prepare("DELETE FROM {$bedsTable} WHERE id = ?");
            $stmt->bind_param('i', $bedId);
            $stmt->execute();
            $stmt->close();
            $message = 'Bed deleted.';
        }
    }
}

$editRoomId = (int)($_GET['edit_room'] ?? 0);
if ($editRoomId > 0) {
    $stmt = $conn->prepare("SELECT * FROM {$roomsTable} WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $editRoomId);
    $stmt->execute();
    $result = $stmt->get_result();
    $selectedRoom = $result->fetch_assoc();
    $stmt->close();

    if ($selectedRoom) {
        $roomForm = [
            'room_id' => (int)$selectedRoom['id'],
            'name' => (string)$selectedRoom['name'],
            'description' => (string)($selectedRoom['description'] ?? ''),
            'floor' => (int)($selectedRoom['floor'] ?? 1),
            'room_type' => (string)($selectedRoom['room_type'] ?? 'Shared'),
            'pricing_mode' => (string)($selectedRoom['pricing_mode'] ?? 'Per Bed'),
            'capacity' => (int)($selectedRoom['capacity'] ?? 4),
            'monthly_rate' => (string)($selectedRoom['monthly_rate'] ?? ''),
            'weekly_rate' => (string)($selectedRoom['weekly_rate'] ?? ''),
            'daily_rate' => (string)($selectedRoom['daily_rate'] ?? ''),
            'amenities' => (string)($selectedRoom['amenities'] ?? ''),
            'is_active' => (int)($selectedRoom['is_active'] ?? 1),
            'image_path' => (string)($selectedRoom['image_path'] ?? ''),
        ];
    }
}

$editBedId = (int)($_GET['edit_bed'] ?? 0);
if ($editBedId > 0) {
    $stmt = $conn->prepare("SELECT * FROM {$bedsTable} WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $editBedId);
    $stmt->execute();
    $result = $stmt->get_result();
    $selectedBed = $result->fetch_assoc();
    $stmt->close();

    if ($selectedBed) {
        $bedForm = [
            'bed_id' => (int)$selectedBed['id'],
            'room_id' => (string)($selectedBed['room_id'] ?? ''),
            'bed_number' => (string)$selectedBed['bed_number'],
            'type' => (string)($selectedBed['type'] ?? 'Single'),
            'status' => (string)($selectedBed['status'] ?? 'Available'),
            'price' => (string)($selectedBed['price'] ?? ''),
            'notes' => (string)($selectedBed['notes'] ?? ''),
            'image_path' => (string)($selectedBed['image_path'] ?? ''),
        ];
    }
}

$rooms = [];
$roomResult = $conn->query(
    "SELECT r.*,
            COUNT(b.id) AS total_beds,
            SUM(b.status = 'Available') AS available_beds,
            SUM(b.status = 'Occupied') AS occupied_beds,
            SUM(b.status = 'Reserved') AS reserved_beds,
            SUM(b.status = 'Maintenance') AS maintenance_beds,
            MIN(NULLIF(b.price, 0)) AS min_bed_rate,
            MAX(NULLIF(b.price, 0)) AS max_bed_rate
     FROM {$roomsTable} r
     LEFT JOIN {$bedsTable} b ON b.room_id = r.id
     GROUP BY r.id
     ORDER BY r.floor, r.name"
);

while ($row = $roomResult->fetch_assoc()) {
    $row['beds'] = [];
    $bedStmt = $conn->prepare("SELECT * FROM {$bedsTable} WHERE room_id = ? ORDER BY bed_number");
    $bedStmt->bind_param('i', $row['id']);
    $bedStmt->execute();
    $bedResult = $bedStmt->get_result();
    while ($bed = $bedResult->fetch_assoc()) {
        $row['beds'][] = $bed;
    }
    $bedStmt->close();
    $rooms[] = $row;
}

bs_admin_shell_start('Room and Bed Management', 'Manage rooms, beds, rates, and photos.', 'rooms');
?>

<?php if ($message !== ''): ?>
  <div class="notice"><?php echo h($message); ?></div>
<?php endif; ?>

<style>
  .room-image-actions {
    display: flex;
    justify-content: flex-start;
    gap: 10px;
    margin-top: 8px;
  }

  .image-modal {
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, 0.82);
    display: none;
    align-items: center;
    justify-content: center;
    padding: 24px;
    z-index: 9999;
  }

  .image-modal.open {
    display: flex;
  }

  .image-modal-panel {
    width: min(1100px, 96vw);
    max-height: 92vh;
    background: #0f172a;
    border-radius: 24px;
    overflow: hidden;
    box-shadow: 0 24px 60px rgba(15, 23, 42, 0.45);
    display: grid;
    grid-template-rows: auto 1fr;
  }

  .image-modal-topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    padding: 18px 20px;
    color: #ffffff;
    background: rgba(255, 255, 255, 0.04);
  }

  .image-modal-topbar h3 {
    margin: 0;
    font-size: 18px;
  }

  .image-modal-close {
    border: none;
    border-radius: 12px;
    padding: 10px 14px;
    background: #fee2e2;
    color: #b91c1c;
    font: inherit;
    font-weight: 700;
    cursor: pointer;
  }

  .image-modal-body {
    background: #020617;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 18px;
  }

  .image-modal-body img {
    max-width: 100%;
    max-height: 78vh;
    object-fit: contain;
    border-radius: 18px;
    background: #ffffff;
  }
</style>

<div class="image-modal" id="roomImageModal" aria-hidden="true">
  <div class="image-modal-panel">
    <div class="image-modal-topbar">
      <h3 id="roomImageModalTitle">Room Image</h3>
      <button type="button" class="image-modal-close" onclick="closeRoomImageModal()">Close</button>
    </div>
    <div class="image-modal-body">
      <img id="roomImageModalPhoto" src="" alt="Room photo preview">
    </div>
  </div>
</div>

<section class="hero">
  <div>
    <h2>Rooms</h2>
    <p>Manage room details, bed inventory, rates, amenities, and images.</p>
    <div class="hero-stats">
      <div class="hero-stat">
        <strong><?php echo count($rooms); ?></strong>
        <span>Total configured rooms</span>
      </div>
      <div class="hero-stat">
        <strong><?php echo array_sum(array_map(fn($room) => (int)$room['total_beds'], $rooms)); ?></strong>
        <span>Total beds tracked</span>
      </div>
      <div class="hero-stat">
        <strong><?php echo array_sum(array_map(fn($room) => (int)$room['available_beds'], $rooms)); ?></strong>
        <span>Available beds right now</span>
      </div>
    </div>
  </div>
  <div class="hero-panel">
    <h3>Summary</h3>
    <div class="stack">
      <div class="stack-item">
        <strong>Rooms</strong>
        <span>Room number, floor, type, rates, amenities, and status.</span>
      </div>
      <div class="stack-item">
        <strong>Beds</strong>
        <span>Bed labels, status, pricing, notes, and images.</span>
      </div>
      <div class="stack-item">
        <strong>Inventory</strong>
        <span>Availability and occupancy by room.</span>
      </div>
    </div>
  </div>
</section>

<section class="two-col">
  <article class="panel">
    <div class="toolbar">
      <h3 style="margin:0;"><?php echo $roomForm['room_id'] > 0 ? 'Edit room' : 'Create or update room'; ?></h3>
      <span class="badge">Rooms and rates</span>
    </div>
    <form class="stack-form" method="post" enctype="multipart/form-data">
      <input type="hidden" name="action" value="save_room">
      <input type="hidden" name="room_id" value="<?php echo h((string)$roomForm['room_id']); ?>">
      <div class="form-grid">
        <div class="field">
          <label for="room_id_display">Room ID</label>
          <input type="number" id="room_id_display" value="<?php echo h((string)$roomForm['room_id']); ?>" placeholder="Auto after create" disabled>
        </div>
        <div class="field">
          <label for="name">Room name / room number</label>
          <input type="text" name="name" id="name" placeholder="Room 401 / Suite A" value="<?php echo h($roomForm['name']); ?>" required>
        </div>
        <div class="field">
          <label for="floor">Floor</label>
          <input type="number" name="floor" id="floor" value="<?php echo h((string)$roomForm['floor']); ?>" min="0">
        </div>
        <div class="field">
          <label for="room_type">Room type</label>
          <select name="room_type" id="room_type">
            <option value="Shared" <?php echo $roomForm['room_type'] === 'Shared' ? 'selected' : ''; ?>>Shared Room</option>
            <option value="Private" <?php echo $roomForm['room_type'] === 'Private' ? 'selected' : ''; ?>>Private Room</option>
          </select>
        </div>
        <div class="field">
          <label for="pricing_mode">Rental mode</label>
          <select name="pricing_mode" id="pricing_mode">
            <option value="Per Bed" <?php echo $roomForm['pricing_mode'] === 'Per Bed' ? 'selected' : ''; ?>>Per Bed</option>
            <option value="Whole Room" <?php echo $roomForm['pricing_mode'] === 'Whole Room' ? 'selected' : ''; ?>>Whole Room</option>
          </select>
        </div>
        <div class="field">
          <label for="capacity">Capacity</label>
          <input type="number" name="capacity" id="capacity" value="<?php echo h((string)$roomForm['capacity']); ?>" min="1">
        </div>
        <div class="field">
          <label for="monthly_rate">Monthly room rate</label>
          <input type="number" step="0.01" name="monthly_rate" id="monthly_rate" placeholder="5000" value="<?php echo h((string)$roomForm['monthly_rate']); ?>">
        </div>
        <div class="field">
          <label for="weekly_rate">Weekly rate</label>
          <input type="number" step="0.01" name="weekly_rate" id="weekly_rate" placeholder="1800" value="<?php echo h((string)$roomForm['weekly_rate']); ?>">
        </div>
        <div class="field">
          <label for="daily_rate">Daily rate</label>
          <input type="number" step="0.01" name="daily_rate" id="daily_rate" placeholder="350" value="<?php echo h((string)$roomForm['daily_rate']); ?>">
        </div>
        <div class="field full">
          <label for="amenities">Amenities</label>
          <input type="text" name="amenities" id="amenities" placeholder="Aircon, Wi-Fi, Own CR, Cabinet, Balcony" value="<?php echo h($roomForm['amenities']); ?>">
        </div>
        <div class="field full">
          <label for="description">Room details</label>
          <textarea name="description" id="description" placeholder="Describe room condition, view, furniture, and privacy."><?php echo h($roomForm['description']); ?></textarea>
        </div>
        <div class="field full">
          <span>
            Set <strong>Private Room</strong> with <strong>Whole Room</strong> when one tenant rents the full room and the price includes all beds.
          </span>
        </div>
        <div class="field">
          <label for="room_image">Room photo</label>
          <input type="file" name="room_image" id="room_image" accept="image/*">
        </div>
        <div class="field">
          <label>
            <input type="checkbox" name="is_active" <?php echo !empty($roomForm['is_active']) ? 'checked' : ''; ?> style="width:auto; margin-right:8px;">
            Room is active and listed
          </label>
          <input type="hidden" name="existing_image_path" value="<?php echo h($roomForm['image_path']); ?>">
          <?php if ($roomForm['image_path'] !== ''): ?>
            <span>Current image: <?php echo h($roomForm['image_path']); ?></span>
          <?php endif; ?>
        </div>
      </div>
      <button type="submit"><?php echo $roomForm['room_id'] > 0 ? 'Update room' : 'Save room'; ?></button>
    </form>
  </article>

  <article class="panel">
    <div class="toolbar">
      <h3 style="margin:0;"><?php echo $bedForm['bed_id'] > 0 ? 'Edit bed' : 'Add or update bed'; ?></h3>
      <span class="badge">Shared room inventory</span>
    </div>
    <form class="stack-form" method="post" enctype="multipart/form-data">
      <input type="hidden" name="action" value="save_bed">
      <input type="hidden" name="bed_id" value="<?php echo h((string)$bedForm['bed_id']); ?>">
      <div class="form-grid">
        <div class="field">
          <label for="bed_id_display">Bed ID</label>
          <input type="number" id="bed_id_display" value="<?php echo h((string)$bedForm['bed_id']); ?>" placeholder="Auto after create" disabled>
        </div>
        <div class="field">
          <label for="bed_room_id">Room ID</label>
          <input type="number" name="room_id" id="bed_room_id" value="<?php echo h((string)$bedForm['room_id']); ?>" required>
        </div>
        <div class="field">
          <label for="bed_number">Bed label</label>
          <input type="text" name="bed_number" id="bed_number" placeholder="Bed 1 / Upper A" value="<?php echo h($bedForm['bed_number']); ?>" required>
        </div>
        <div class="field">
          <label for="type">Bed type</label>
          <select name="type" id="type">
            <option value="Single" <?php echo $bedForm['type'] === 'Single' ? 'selected' : ''; ?>>Single</option>
            <option value="Upper" <?php echo $bedForm['type'] === 'Upper' ? 'selected' : ''; ?>>Upper</option>
            <option value="Lower" <?php echo $bedForm['type'] === 'Lower' ? 'selected' : ''; ?>>Lower</option>
            <option value="Double" <?php echo $bedForm['type'] === 'Double' ? 'selected' : ''; ?>>Double</option>
          </select>
        </div>
        <div class="field">
          <label for="status">Status</label>
          <select name="status" id="status">
            <option value="Available" <?php echo $bedForm['status'] === 'Available' ? 'selected' : ''; ?>>Available</option>
            <option value="Occupied" <?php echo $bedForm['status'] === 'Occupied' ? 'selected' : ''; ?>>Occupied</option>
            <option value="Reserved" <?php echo $bedForm['status'] === 'Reserved' ? 'selected' : ''; ?>>Reserved</option>
            <option value="Maintenance" <?php echo $bedForm['status'] === 'Maintenance' ? 'selected' : ''; ?>>Maintenance</option>
          </select>
        </div>
        <div class="field">
          <label for="price">Bed rate</label>
          <input type="number" step="0.01" name="price" id="price" placeholder="3500" value="<?php echo h((string)$bedForm['price']); ?>">
        </div>
        <div class="field full">
          <label for="notes">Bed notes</label>
          <textarea name="notes" id="notes" placeholder="Near window, with curtain rail, premium mattress, etc."><?php echo h($bedForm['notes']); ?></textarea>
        </div>
        <div class="field">
          <label for="bed_image">Bed photo</label>
          <input type="file" name="bed_image" id="bed_image" accept="image/*">
          <input type="hidden" name="existing_image_path" value="<?php echo h($bedForm['image_path']); ?>">
          <?php if ($bedForm['image_path'] !== ''): ?>
            <span>Current image: <?php echo h($bedForm['image_path']); ?></span>
          <?php endif; ?>
        </div>
      </div>
      <button type="submit"><?php echo $bedForm['bed_id'] > 0 ? 'Update bed' : 'Save bed'; ?></button>
    </form>
  </article>
</section>

<section class="panel" style="margin-top:18px;">
  <div class="toolbar">
    <h3 style="margin:0;">Live room inventory</h3>
    <span class="badge"><?php echo count($rooms); ?> rooms in database</span>
  </div>

  <?php if (!$rooms): ?>
    <div class="empty">No rooms found.</div>
  <?php else: ?>
    <div class="room-card-list">
      <?php foreach ($rooms as $room): ?>
        <div class="room-card">
          <div class="room-card-body">
            <div class="toolbar" style="margin:0;">
              <div>
                <h3 style="margin:0 0 8px;"><?php echo h($room['name']); ?></h3>
                <div class="room-meta">
                  <span class="meta-pill">Floor <?php echo h((string)$room['floor']); ?></span>
                  <span class="meta-pill"><?php echo h($room['room_type'] ?? 'Shared'); ?></span>
                  <span class="meta-pill"><?php echo h($room['pricing_mode'] ?? 'Per Bed'); ?></span>
                  <span class="meta-pill">Capacity <?php echo h((string)($room['capacity'] ?? 0)); ?></span>
                  <span class="status-pill <?php echo !empty($room['is_active']) ? 'active' : 'reserved'; ?>">
                    <?php echo !empty($room['is_active']) ? 'Active' : 'Inactive'; ?>
                  </span>
                </div>
              </div>
              <form class="inline" method="post" onsubmit="return confirm('Delete this room and all visible room data?');">
                <input type="hidden" name="action" value="delete_room">
                <input type="hidden" name="room_id" value="<?php echo h((string)$room['id']); ?>">
                <a class="button secondary" href="rooms.php?edit_room=<?php echo h((string)$room['id']); ?>">Edit room</a>
                <button type="submit" class="button-danger">Delete room</button>
              </form>
            </div>

            <div>
              <strong>Room details</strong>
              <span><?php echo h($room['description'] ?: 'No room description added yet.'); ?></span>
            </div>

            <?php if (!empty($room['image_path'])): ?>
              <div class="room-image-actions">
                <button
                  type="button"
                  class="button secondary"
                  data-room-image="<?php echo h('../' . $room['image_path']); ?>"
                  data-room-title="<?php echo h($room['name']); ?>"
                  data-room-viewer
                >
                  View photo
                </button>
              </div>
            <?php endif; ?>

            <div class="room-meta">
              <?php if (!empty($room['amenities'])): ?>
                <?php foreach (array_filter(array_map('trim', explode(',', (string)$room['amenities']))) as $amenity): ?>
                  <span class="meta-pill"><?php echo h($amenity); ?></span>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>

            <div class="cards" style="grid-template-columns: repeat(4, minmax(0, 1fr)); margin:0;">
              <div class="card">
                <div class="card-label">Monthly</div>
                <strong><?php echo h(bs_currency($conn)) . h(number_format((float)($room['monthly_rate'] ?? 0), 2)); ?></strong>
                <span><?php echo ($room['pricing_mode'] ?? 'Per Bed') === 'Whole Room' ? 'Whole-room monthly rate' : 'Room monthly rate'; ?></span>
              </div>
              <div class="card">
                <div class="card-label">Weekly</div>
                <strong><?php echo h(bs_currency($conn)) . h(number_format((float)($room['weekly_rate'] ?? 0), 2)); ?></strong>
                <span><?php echo ($room['pricing_mode'] ?? 'Per Bed') === 'Whole Room' ? 'Whole-room weekly rate' : 'Weekly room pricing'; ?></span>
              </div>
              <div class="card">
                <div class="card-label">Daily</div>
                <strong><?php echo h(bs_currency($conn)) . h(number_format((float)($room['daily_rate'] ?? 0), 2)); ?></strong>
                <span><?php echo ($room['pricing_mode'] ?? 'Per Bed') === 'Whole Room' ? 'Whole-room daily rate' : 'Short-stay pricing'; ?></span>
              </div>
              <div class="card">
                <div class="card-label"><?php echo ($room['pricing_mode'] ?? 'Per Bed') === 'Whole Room' ? 'Included Beds' : 'Beds'; ?></div>
                <strong><?php echo h((string)$room['total_beds']); ?></strong>
                <span>
                  <?php if (($room['pricing_mode'] ?? 'Per Bed') === 'Whole Room'): ?>
                    Entire room rental includes all beds
                  <?php else: ?>
                    <?php echo h((string)$room['available_beds']); ?> available / <?php echo h((string)$room['occupied_beds']); ?> occupied
                  <?php endif; ?>
                </span>
              </div>
            </div>

            <div class="table-shell">
              <div class="table-row head">
                <strong>Bed</strong>
                <strong>Type</strong>
                <strong>Status</strong>
                <strong>Rate</strong>
                <strong>Image</strong>
                <strong>Action</strong>
              </div>
              <?php if (!$room['beds']): ?>
                <div class="empty">No beds assigned to this room yet.</div>
              <?php else: ?>
                <?php foreach ($room['beds'] as $bed): ?>
                  <div class="table-row">
                    <div>
                      <strong><?php echo h($bed['bed_number']); ?></strong>
                      <span><?php echo h($bed['notes'] ?: 'No notes'); ?></span>
                    </div>
                    <div><?php echo h($bed['type']); ?></div>
                    <div><span class="status-pill <?php echo strtolower(str_replace(' ', '', (string)$bed['status'])); ?>"><?php echo h($bed['status']); ?></span></div>
                    <div><?php echo h(bs_currency($conn)) . h(number_format((float)$bed['price'], 2)); ?></div>
                    <div><?php echo $bed['image_path'] ? 'Uploaded' : 'None'; ?></div>
                    <div>
                      <form class="inline" method="post" onsubmit="return confirm('Delete this bed?');">
                        <input type="hidden" name="action" value="delete_bed">
                        <input type="hidden" name="bed_id" value="<?php echo h((string)$bed['id']); ?>">
                        <a class="button secondary" href="rooms.php?edit_bed=<?php echo h((string)$bed['id']); ?>">Edit</a>
                        <button type="submit" class="button-danger">Delete</button>
                      </form>
                    </div>
                  </div>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>

<script>
  (function () {
    const modal = document.getElementById('roomImageModal');
    const photo = document.getElementById('roomImageModalPhoto');
    const heading = document.getElementById('roomImageModalTitle');
    const triggers = document.querySelectorAll('[data-room-viewer]');

    function openRoomImageModal(src, title) {
      if (!src) {
        return;
      }
      photo.src = src;
      heading.textContent = title ? title + ' Photo' : 'Room Photo';
      modal.classList.add('open');
      modal.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
    }

    window.closeRoomImageModal = function () {
      modal.classList.remove('open');
      modal.setAttribute('aria-hidden', 'true');
      photo.src = '';
      document.body.style.overflow = '';
    };

    triggers.forEach(function (button) {
      button.addEventListener('click', function () {
        openRoomImageModal(button.getAttribute('data-room-image'), button.getAttribute('data-room-title'));
      });
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        window.closeRoomImageModal();
      }
    });

    modal.addEventListener('click', function (event) {
      if (event.target === modal) {
        window.closeRoomImageModal();
      }
    });
  })();
</script>

<?php
bs_admin_shell_end();
