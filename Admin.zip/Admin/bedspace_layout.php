<?php
require_once __DIR__ . '/../bedspace_bootstrap.php';

function bs_admin_shell_start(string $title, string $subtitle, string $active): void {
    $nav = [
        'dashboard' => ['admin_dashboard.php', 'DB', 'Dashboard'],
        'rooms' => ['rooms.php', 'RM', 'Rooms'],
        'maintenance' => ['maintenance.php', 'MT', 'Maintenance'],
        'payments' => ['payments.php', 'PY', 'Payments'],
        'old_admin' => ['fees.php', 'LG', 'Legacy Fees'],
        'logout' => ['../index.html', 'OUT', 'Logout'],
    ];
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo h($title); ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="bedspace_admin.css">
</head>
<body>
  <div class="layout">
    <aside class="sidebar">
      <div class="brand">
        <div class="brand-mark">BS</div>
        <div>
          <strong>BedSpace</strong>
          <span>Ready Deployment</span>
        </div>
      </div>

      <div class="nav-label">Core</div>
      <?php foreach ($nav as $key => $item): ?>
        <a class="nav-link <?php echo $active === $key ? 'active' : ''; ?>" href="<?php echo h($item[0]); ?>">
          <span><?php echo h($item[1]); ?></span>
          <span><?php echo h($item[2]); ?></span>
        </a>
      <?php endforeach; ?>
    </aside>

    <main class="content">
      <div class="topbar">
        <div>
          <h1><?php echo h($title); ?></h1>
          <p><?php echo h($subtitle); ?></p>
        </div>
        <div class="badge">BedSpacer data model</div>
      </div>
<?php
}

function bs_admin_shell_end(): void {
    ?>
    </main>
  </div>
</body>
</html>
<?php
}
