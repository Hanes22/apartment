<?php
require_once __DIR__ . '/../bedspace_bootstrap.php';
require_once __DIR__ . '/bedspace_layout.php';

bs_ensure_schema($conn);

$maintenanceTable = bs_table('maintenance');
$tenantsTable = bs_table('tenants');
$bedsTable = bs_table('beds');
$roomsTable = bs_table('rooms');
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'report_issue') {
        $tenantId = $_POST['tenant_id'] !== '' ? (int)$_POST['tenant_id'] : null;
        $bedId = $_POST['bed_id'] !== '' ? (int)$_POST['bed_id'] : null;
        $roomId = $_POST['room_id'] !== '' ? (int)$_POST['room_id'] : null;
        $issue = trim($_POST['issue'] ?? '');
        $priority = $_POST['priority'] ?? 'Normal';
        $category = trim($_POST['category'] ?? 'General');
        $photoPath = bs_handle_image_upload('issue_photo', 'maintenance');

        if ($issue !== '') {
            $stmt = $conn->prepare(
                "INSERT INTO {$maintenanceTable} (tenant_id, bed_id, room_id, issue, priority, category, photo_path)
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            $stmt->bind_param('iiissss', $tenantId, $bedId, $roomId, $issue, $priority, $category, $photoPath);
            $stmt->execute();
            $stmt->close();
            $message = 'Maintenance issue created.';
        }
    }

    if ($action === 'update_issue') {
        $issueId = (int)($_POST['issue_id'] ?? 0);
        $status = $_POST['status'] ?? 'Pending';
        $notes = trim($_POST['admin_notes'] ?? '');
        $resolved = $status === 'Fixed' ? date('Y-m-d H:i:s') : null;

        if ($issueId > 0) {
            $stmt = $conn->prepare(
                "UPDATE {$maintenanceTable}
                 SET status=?, date_resolved=?, admin_notes=?
                 WHERE id=?"
            );
            $stmt->bind_param('sssi', $status, $resolved, $notes, $issueId);
            $stmt->execute();
            $stmt->close();
            $message = 'Maintenance ticket updated.';
        }
    }

    if ($action === 'delete_issue') {
        $issueId = (int)($_POST['issue_id'] ?? 0);
        if ($issueId > 0) {
            $stmt = $conn->prepare("DELETE FROM {$maintenanceTable} WHERE id = ?");
            $stmt->bind_param('i', $issueId);
            $stmt->execute();
            $stmt->close();
            $message = 'Maintenance ticket deleted.';
        }
    }
}

$tenants = $conn->query("SELECT id, name FROM {$tenantsTable} ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$beds = $conn->query("SELECT id, bed_number FROM {$bedsTable} ORDER BY room_id, bed_number")->fetch_all(MYSQLI_ASSOC);
$rooms = $conn->query("SELECT id, name FROM {$roomsTable} ORDER BY floor, name")->fetch_all(MYSQLI_ASSOC);

$issues = $conn->query(
    "SELECT m.*, t.name AS tenant_name, b.bed_number, r.name AS room_name
     FROM {$maintenanceTable} m
     LEFT JOIN {$tenantsTable} t ON t.id = m.tenant_id
     LEFT JOIN {$bedsTable} b ON b.id = m.bed_id
     LEFT JOIN {$roomsTable} r ON r.id = m.room_id
     ORDER BY m.date_submitted DESC"
)->fetch_all(MYSQLI_ASSOC);

bs_admin_shell_start('Maintenance', 'Track maintenance issues and update status.', 'maintenance');
?>

<?php if ($message !== ''): ?>
  <div class="notice"><?php echo h($message); ?></div>
<?php endif; ?>

<section class="hero">
  <div>
    <h2>Maintenance</h2>
    <p>Track reported issues, assign room or bed context, and update status.</p>
    <div class="hero-stats">
      <div class="hero-stat">
        <strong><?php echo count($issues); ?></strong>
        <span>Total maintenance tickets</span>
      </div>
      <div class="hero-stat">
        <strong><?php echo count(array_filter($issues, fn($item) => $item['status'] === 'Pending')); ?></strong>
        <span>Pending reports</span>
      </div>
      <div class="hero-stat">
        <strong><?php echo count(array_filter($issues, fn($item) => $item['status'] === 'Fixed')); ?></strong>
        <span>Fixed issues</span>
      </div>
    </div>
  </div>
  <div class="hero-panel">
    <h3>Status flow</h3>
    <div class="stack">
      <div class="stack-item">
        <strong>Pending</strong>
        <span>New report awaiting action.</span>
      </div>
      <div class="stack-item">
        <strong>In Progress</strong>
        <span>Issue is being handled.</span>
      </div>
      <div class="stack-item">
        <strong>Fixed</strong>
        <span>Issue completed and recorded.</span>
      </div>
    </div>
  </div>
</section>

<section class="two-col">
  <article class="panel">
    <h3>Report a maintenance issue</h3>
    <form class="stack-form" method="post" enctype="multipart/form-data">
      <input type="hidden" name="action" value="report_issue">
      <div class="form-grid">
        <div class="field">
          <label for="tenant_id">Tenant</label>
          <select name="tenant_id" id="tenant_id">
            <option value="">Optional</option>
            <?php foreach ($tenants as $tenant): ?>
              <option value="<?php echo h((string)$tenant['id']); ?>"><?php echo h($tenant['name']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label for="room_id">Room</label>
          <select name="room_id" id="room_id">
            <option value="">Optional</option>
            <?php foreach ($rooms as $room): ?>
              <option value="<?php echo h((string)$room['id']); ?>"><?php echo h($room['name']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label for="bed_id">Bed</label>
          <select name="bed_id" id="bed_id">
            <option value="">Optional</option>
            <?php foreach ($beds as $bed): ?>
              <option value="<?php echo h((string)$bed['id']); ?>"><?php echo h($bed['bed_number']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label for="category">Category</label>
          <select name="category" id="category">
            <option value="General">General</option>
            <option value="Plumbing">Plumbing</option>
            <option value="Electrical">Electrical</option>
            <option value="Aircon">Aircon</option>
            <option value="Furniture">Furniture</option>
            <option value="Cleaning">Cleaning</option>
            <option value="Security">Security</option>
          </select>
        </div>
        <div class="field">
          <label for="priority">Priority</label>
          <select name="priority" id="priority">
            <option value="Low">Low</option>
            <option value="Normal" selected>Normal</option>
            <option value="High">High</option>
          </select>
        </div>
        <div class="field">
          <label for="issue_photo">Problem photo</label>
          <input type="file" name="issue_photo" id="issue_photo" accept="image/*">
        </div>
        <div class="field full">
          <label for="issue">Problem description</label>
          <textarea name="issue" id="issue" placeholder="Example: Private room AC not cooling, water leak near CR, socket sparks when charging." required></textarea>
        </div>
      </div>
      <button type="submit">Create maintenance ticket</button>
    </form>
  </article>

  <article class="panel">
    <h3>Notes</h3>
    <div class="stack">
      <div class="stack-item">
        <strong>Location</strong>
        <span>Add room or bed when available.</span>
      </div>
      <div class="stack-item">
        <strong>Photo</strong>
        <span>Upload an image when needed.</span>
      </div>
      <div class="stack-item">
        <strong>Status</strong>
        <span>Keep tickets updated.</span>
      </div>
    </div>
  </article>
</section>

<section class="panel" style="margin-top:18px;">
  <div class="toolbar">
    <h3 style="margin:0;">Live maintenance tickets</h3>
    <span class="badge"><?php echo count($issues); ?> total</span>
  </div>

  <?php if (!$issues): ?>
    <div class="empty">No maintenance issues reported yet.</div>
  <?php else: ?>
    <div class="room-card-list">
      <?php foreach ($issues as $issue): ?>
        <div class="room-card">
          <div class="room-card-image" style="<?php echo $issue['photo_path'] ? "background-image:url('../" . h($issue['photo_path']) . "');" : ''; ?>"></div>
          <div class="room-card-body">
            <div class="toolbar" style="margin:0;">
              <div>
                <h3 style="margin:0 0 8px;"><?php echo h($issue['category'] ?? 'General'); ?> Issue #<?php echo h((string)$issue['id']); ?></h3>
                <div class="room-meta">
                  <span class="status-pill <?php echo strtolower(str_replace(' ', '', (string)$issue['status'])); ?>"><?php echo h($issue['status']); ?></span>
                  <span class="meta-pill">Priority <?php echo h($issue['priority']); ?></span>
                  <?php if (!empty($issue['room_name'])): ?><span class="meta-pill"><?php echo h($issue['room_name']); ?></span><?php endif; ?>
                  <?php if (!empty($issue['bed_number'])): ?><span class="meta-pill"><?php echo h($issue['bed_number']); ?></span><?php endif; ?>
                  <?php if (!empty($issue['tenant_name'])): ?><span class="meta-pill"><?php echo h($issue['tenant_name']); ?></span><?php endif; ?>
                </div>
              </div>
              <form class="inline" method="post" onsubmit="return confirm('Delete this maintenance ticket?');">
                <input type="hidden" name="action" value="delete_issue">
                <input type="hidden" name="issue_id" value="<?php echo h((string)$issue['id']); ?>">
                <button type="submit" class="button-danger">Delete</button>
              </form>
            </div>

            <div>
              <strong>Reported problem</strong>
              <span><?php echo h($issue['issue']); ?></span>
            </div>

            <div>
              <strong>Submitted</strong>
              <span><?php echo h((string)$issue['date_submitted']); ?></span>
            </div>

            <?php if (!empty($issue['admin_notes'])): ?>
              <div>
                <strong>Admin notes</strong>
                <span><?php echo h($issue['admin_notes']); ?></span>
              </div>
            <?php endif; ?>

            <form class="stack-form" method="post">
              <input type="hidden" name="action" value="update_issue">
              <input type="hidden" name="issue_id" value="<?php echo h((string)$issue['id']); ?>">
              <div class="form-grid">
                <div class="field">
                  <label>Status</label>
                  <select name="status">
                    <?php foreach (['Pending', 'In Progress', 'Fixed'] as $status): ?>
                      <option value="<?php echo h($status); ?>" <?php echo $issue['status'] === $status ? 'selected' : ''; ?>>
                        <?php echo h($status); ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="field full">
                  <label>Fixing notes / action taken</label>
                  <textarea name="admin_notes" placeholder="Assigned technician, bought parts, fixed leak, replaced switch, etc."><?php echo h((string)$issue['admin_notes']); ?></textarea>
                </div>
              </div>
              <button type="submit">Update maintenance ticket</button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>

<?php
bs_admin_shell_end();
