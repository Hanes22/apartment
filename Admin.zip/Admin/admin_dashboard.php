<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BedSpace Admin Dashboard</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --navy: #0f172a;
      --slate: #1e293b;
      --panel: #ffffff;
      --surface: #f8fafc;
      --line: #e2e8f0;
      --text: #0f172a;
      --muted: #64748b;
      --primary: #3d8ef0;
      --success: #22c55e;
      --danger: #ef4444;
      --warning: #f59e0b;
    }

    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: "Inter", sans-serif;
      background: var(--surface);
      color: var(--text);
    }

    a { text-decoration: none; color: inherit; }

    .layout {
      min-height: 100vh;
      display: grid;
      grid-template-columns: 280px 1fr;
    }

    .sidebar {
      background: linear-gradient(180deg, #0f172a 0%, #172235 100%);
      color: #e2e8f0;
      padding: 24px 18px;
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    .brand {
      display: flex;
      gap: 14px;
      align-items: center;
      padding: 8px 10px 18px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }

    .mark {
      width: 48px;
      height: 48px;
      border-radius: 16px;
      display: grid;
      place-items: center;
      background: linear-gradient(135deg, #3d8ef0, #6366f1);
      box-shadow: 0 18px 36px rgba(61, 142, 240, 0.28);
      font-size: 22px;
    }

    .brand strong { display: block; font-size: 16px; }
    .brand span { color: #94a3b8; font-size: 11px; text-transform: uppercase; letter-spacing: 0.08em; }

    .section-label {
      color: #64748b;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      padding: 0 12px;
    }

    .nav-link {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 14px 14px;
      border-radius: 16px;
      color: #cbd5e1;
      font-size: 14px;
      font-weight: 600;
      transition: 0.2s ease;
    }

    .nav-link:hover,
    .nav-link.active {
      background: rgba(255, 255, 255, 0.08);
      color: #fff;
    }

    .content {
      padding: 28px;
    }

    .topbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 16px;
      margin-bottom: 24px;
    }

    .topbar h1 {
      margin: 0;
      font-size: 34px;
      letter-spacing: -0.04em;
    }

    .topbar p {
      margin: 6px 0 0;
      color: var(--muted);
    }

    .badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 10px 14px;
      background: #eff6ff;
      color: #1d4ed8;
      border-radius: 999px;
      font-size: 12px;
      font-weight: 700;
    }

    .hero {
      background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%);
      color: #fff;
      border-radius: 28px;
      padding: 28px;
      display: grid;
      grid-template-columns: 1.1fr 0.9fr;
      gap: 18px;
      box-shadow: 0 24px 50px rgba(15, 23, 42, 0.16);
      margin-bottom: 22px;
    }

    .hero h2 {
      margin: 0 0 10px;
      font-size: 30px;
      line-height: 1.05;
      letter-spacing: -0.04em;
    }

    .hero p {
      margin: 0 0 18px;
      color: rgba(255, 255, 255, 0.78);
      line-height: 1.75;
    }

    .hero-stats {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 12px;
    }

    .hero-stat {
      padding: 16px;
      border-radius: 18px;
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.10);
    }

    .hero-stat strong {
      display: block;
      font-size: 26px;
      margin-bottom: 4px;
    }

    .hero-stat span {
      font-size: 12px;
      color: rgba(255, 255, 255, 0.72);
    }

    .hero-panel {
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.10);
      border-radius: 22px;
      padding: 20px;
      align-self: stretch;
    }

    .cards {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 16px;
      margin-bottom: 22px;
    }

    .card, .table-card {
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 22px;
      box-shadow: 0 12px 28px rgba(15, 23, 42, 0.05);
    }

    .card {
      padding: 20px;
    }

    .card .label {
      color: var(--muted);
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
    }

    .card strong {
      display: block;
      font-size: 30px;
      margin: 10px 0 6px;
      letter-spacing: -0.04em;
    }

    .card span {
      color: var(--muted);
      font-size: 13px;
      line-height: 1.6;
    }

    .grid {
      display: grid;
      grid-template-columns: 1.15fr 0.85fr;
      gap: 18px;
    }

    .table-card,
    .action-card {
      padding: 22px;
    }

    .table-card h3,
    .action-card h3 {
      margin: 0 0 16px;
      font-size: 20px;
      letter-spacing: -0.03em;
    }

    .mini-table {
      display: grid;
      gap: 10px;
    }

    .row {
      display: grid;
      grid-template-columns: 1fr auto;
      gap: 12px;
      align-items: center;
      padding: 14px 16px;
      background: #f8fafc;
      border: 1px solid var(--line);
      border-radius: 16px;
    }

    .row strong {
      display: block;
      margin-bottom: 4px;
      font-size: 14px;
    }

    .row span {
      color: var(--muted);
      font-size: 12px;
    }

    .status {
      padding: 8px 10px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 800;
    }

    .status.success { background: #dcfce7; color: #15803d; }
    .status.warn { background: #fef3c7; color: #b45309; }
    .status.danger { background: #fee2e2; color: #b91c1c; }

    .actions {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 12px;
    }

    .action {
      padding: 18px;
      border-radius: 18px;
      border: 1px solid var(--line);
      background: #f8fafc;
      transition: 0.2s ease;
    }

    .action:hover { transform: translateY(-2px); border-color: #cbd5e1; }
    .action strong { display: block; margin-bottom: 6px; font-size: 15px; }
    .action span { color: var(--muted); font-size: 12px; line-height: 1.6; }

    @media (max-width: 1100px) {
      .cards { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .grid, .hero { grid-template-columns: 1fr; }
    }

    @media (max-width: 800px) {
      .layout { grid-template-columns: 1fr; }
      .cards, .actions, .hero-stats { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <div class="layout">
    <aside class="sidebar">
      <div class="brand">
        <div class="mark">🏠</div>
        <div>
          <strong>BedSpace</strong>
          <span>Admin Console</span>
        </div>
      </div>

      <div class="section-label">Overview</div>
      <a class="nav-link active" href="admin_dashboard.php">📊 Dashboard</a>
      <a class="nav-link" href="rooms.php">🏠 Rooms and Beds</a>
      <a class="nav-link" href="maintenance.php">🛠 Maintenance</a>
      <a class="nav-link" href="payments.php">💳 Payments</a>
      <a class="nav-link" href="../Employee/empdashboard.php">🧰 Employee View</a>
      <a class="nav-link" href="../Tenant/tenant_dashboard.php">🧍 Tenant View</a>

      <div class="section-label">Operations</div>
      <a class="nav-link" href="../Owner/viewempl.php">👥 Employee Directory</a>
      <a class="nav-link" href="viewenq.php">📨 Enquiries</a>
      <a class="nav-link" href="parkingslot.php">🚗 Parking</a>
      <a class="nav-link" href="fees.php">💳 Fees</a>
      <a class="nav-link" href="export.php">📤 Export Data</a>
      <a class="nav-link" href="../index.html">↩ Logout</a>
    </aside>

    <main class="content">
      <div class="topbar">
        <div>
          <h1>Admin Dashboard</h1>
          <p>Room, tenant, maintenance, and payment management.</p>
        </div>
        <div class="badge">Admin</div>
      </div>

      <section class="hero">
        <div>
          <h2>Operations overview</h2>
          <p>Use this dashboard to manage rooms, payments, maintenance, staff, and tenant activity.</p>
          <div class="hero-stats">
            <div class="hero-stat">
              <strong>4</strong>
              <span>Main modules</span>
            </div>
            <div class="hero-stat">
              <strong>1 DB</strong>
              <span>Database</span>
            </div>
            <div class="hero-stat">
              <strong>24/7</strong>
              <span>Online access</span>
            </div>
          </div>
        </div>
        <div class="hero-panel">
          <h3 style="margin:0 0 14px;font-size:18px;">Today</h3>
          <div class="mini-table">
            <div class="row">
              <div>
                <strong>Review enquiries</strong>
                <span>Check new prospect messages.</span>
              </div>
              <div class="status success">Ready</div>
            </div>
            <div class="row">
              <div>
                <strong>Check staff and tenants</strong>
                <span>Open daily operations pages.</span>
              </div>
              <div class="status warn">Daily</div>
            </div>
            <div class="row">
              <div>
                <strong>Export reports</strong>
                <span>Download records when needed.</span>
              </div>
              <div class="status danger">Monthly</div>
            </div>
          </div>
        </div>
      </section>

      <section class="cards">
        <article class="card">
          <div class="label">Staff</div>
          <strong>Employee Ops</strong>
          <span>Employee records and daily tasks.</span>
        </article>
        <article class="card">
          <div class="label">Residents</div>
          <strong>Tenant Access</strong>
          <span>Tenant records, requests, and status.</span>
        </article>
        <article class="card">
          <div class="label">Facilities</div>
          <strong>Parking & Rooms</strong>
          <span>Rooms, beds, and parking.</span>
        </article>
        <article class="card">
          <div class="label">Finance</div>
          <strong>Fees & Export</strong>
          <span>Payments, fees, and exports.</span>
        </article>
      </section>

      <section class="grid">
        <article class="table-card">
          <h3>Modules</h3>
          <div class="mini-table">
            <div class="row">
              <div>
                <strong>Rooms, beds, and rates</strong>
                <span>Manage rooms, beds, rates, and photos.</span>
              </div>
              <a href="rooms.php" class="status success">Open</a>
            </div>
            <div class="row">
              <div>
                <strong>Maintenance</strong>
                <span>Track issues and update status.</span>
              </div>
              <a href="maintenance.php" class="status warn">Manage</a>
            </div>
            <div class="row">
              <div>
                <strong>Payments</strong>
                <span>Billing, collections, and references.</span>
              </div>
              <a href="payments.php" class="status success">Collect</a>
            </div>
            <div class="row">
              <div>
                <strong>Enquiries</strong>
                <span>Prospect records and follow-up.</span>
              </div>
              <a href="viewenq.php" class="status success">Open</a>
            </div>
            <div class="row">
              <div>
                <strong>Exports</strong>
                <span>Download current records.</span>
              </div>
              <a href="export.php" class="status danger">Export</a>
            </div>
          </div>
        </article>

        <article class="action-card table-card">
          <h3>Quick actions</h3>
          <div class="actions">
            <a class="action" href="../Owner/viewempl.php">
              <strong>View Employees</strong>
              <span>Open employee records.</span>
            </a>
            <a class="action" href="rooms.php">
              <strong>Manage Rooms</strong>
              <span>Edit rooms, beds, rates, and photos.</span>
            </a>
            <a class="action" href="maintenance.php">
              <strong>Maintenance Desk</strong>
              <span>Review maintenance tickets.</span>
            </a>
            <a class="action" href="payments.php">
              <strong>Payment Center</strong>
              <span>Record and review payments.</span>
            </a>
            <a class="action" href="viewenq.php">
              <strong>Check Enquiries</strong>
              <span>Review new enquiries.</span>
            </a>
            <a class="action" href="export.php">
              <strong>Export Reports</strong>
              <span>Export current records.</span>
            </a>
          </div>
        </article>
      </section>
    </main>
  </div>
</body>
</html>
