<?php
require_once __DIR__ . '/config.php';

$bedspacePrefix = 'bedspacer_';

function h(?string $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function bs_table(string $name): string {
    global $bedspacePrefix;
    return $bedspacePrefix . $name;
}

function bs_upload_dir(string $subdir): string {
    $base = __DIR__ . '/uploads/' . trim($subdir, '/');
    if (!is_dir($base)) {
        mkdir($base, 0775, true);
    }
    return $base;
}

function bs_handle_image_upload(string $field, string $subdir, ?string $existing = null): ?string {
    if (!isset($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
        return $existing;
    }

    if ($_FILES[$field]['error'] !== UPLOAD_ERR_OK) {
        return $existing;
    }

    $tmp = $_FILES[$field]['tmp_name'];
    $mime = mime_content_type($tmp);
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
    ];

    if (!isset($allowed[$mime])) {
        return $existing;
    }

    $dir = bs_upload_dir($subdir);
    $filename = strtolower($subdir) . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $allowed[$mime];
    $target = $dir . '/' . $filename;

    if (move_uploaded_file($tmp, $target)) {
        return 'uploads/' . trim($subdir, '/') . '/' . $filename;
    }

    return $existing;
}

function bs_setting(mysqli $conn, string $key, string $default = ''): string {
    $table = bs_table('settings');
    $stmt = $conn->prepare("SELECT value FROM {$table} WHERE key_name = ? LIMIT 1");
    if (!$stmt) {
        return $default;
    }
    $stmt->bind_param('s', $key);
    $stmt->execute();
    $stmt->bind_result($value);
    $found = $stmt->fetch();
    $stmt->close();
    return $found ? (string)$value : $default;
}

function bs_currency(mysqli $conn): string {
    $currency = bs_setting($conn, 'currency', 'PHP');
    return trim($currency) !== '' ? $currency : 'PHP';
}

function bs_payment_methods(): array {
    return ['GCash', 'Card', 'Cash', 'Bank Transfer'];
}

function bs_payment_channels(): array {
    return ['Online', 'Walk-in', 'Auto Debit', 'Manual Entry'];
}

function bs_ensure_schema(mysqli $conn): void {
    static $done = false;
    if ($done) {
        return;
    }

    $rooms = bs_table('rooms');
    $beds = bs_table('beds');
    $maintenance = bs_table('maintenance');
    $payments = bs_table('payments');
    $tenants = bs_table('tenants');
    $users = bs_table('users');

    $queries = [
        "ALTER TABLE {$rooms} ADD COLUMN IF NOT EXISTS room_type ENUM('Shared','Private') DEFAULT 'Shared'",
        "ALTER TABLE {$rooms} ADD COLUMN IF NOT EXISTS capacity INT DEFAULT 4",
        "ALTER TABLE {$rooms} ADD COLUMN IF NOT EXISTS monthly_rate DECIMAL(10,2) DEFAULT 0.00",
        "ALTER TABLE {$rooms} ADD COLUMN IF NOT EXISTS weekly_rate DECIMAL(10,2) DEFAULT 0.00",
        "ALTER TABLE {$rooms} ADD COLUMN IF NOT EXISTS daily_rate DECIMAL(10,2) DEFAULT 0.00",
        "ALTER TABLE {$rooms} ADD COLUMN IF NOT EXISTS pricing_mode ENUM('Per Bed','Whole Room') DEFAULT 'Per Bed'",
        "ALTER TABLE {$rooms} ADD COLUMN IF NOT EXISTS amenities TEXT DEFAULT NULL",
        "ALTER TABLE {$rooms} ADD COLUMN IF NOT EXISTS is_active TINYINT(1) DEFAULT 1",
        "ALTER TABLE {$beds} ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT NULL",
        "ALTER TABLE {$maintenance} ADD COLUMN IF NOT EXISTS category VARCHAR(60) DEFAULT 'General'",
        "ALTER TABLE {$maintenance} ADD COLUMN IF NOT EXISTS photo_path VARCHAR(255) DEFAULT NULL",
        "ALTER TABLE {$payments} ADD COLUMN IF NOT EXISTS payment_method VARCHAR(40) DEFAULT NULL",
        "ALTER TABLE {$payments} ADD COLUMN IF NOT EXISTS payment_channel VARCHAR(40) DEFAULT NULL",
        "ALTER TABLE {$payments} ADD COLUMN IF NOT EXISTS transaction_reference VARCHAR(100) DEFAULT NULL",
        "ALTER TABLE {$tenants} ADD COLUMN IF NOT EXISTS username VARCHAR(60) DEFAULT NULL",
        "ALTER TABLE {$tenants} ADD COLUMN IF NOT EXISTS password_hash VARCHAR(255) DEFAULT NULL",
        "ALTER TABLE {$tenants} ADD COLUMN IF NOT EXISTS last_login DATETIME DEFAULT NULL",
        "ALTER TABLE {$users} MODIFY COLUMN role ENUM('admin','staff') DEFAULT 'staff'",
    ];

    foreach ($queries as $query) {
        $conn->query($query);
    }

    $done = true;
}
