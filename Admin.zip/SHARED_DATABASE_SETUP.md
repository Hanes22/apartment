## Shared Database Setup

This project can live inside an existing MySQL/MariaDB database as long as you import only its own tables and do not run the original dump unchanged.

### Why the original SQL is risky

The file `apartment_management(1).sql` contains `DROP TABLE IF EXISTS ...` statements.
If you import that file without reviewing it, it can delete tables that happen to share the same names.

### Safer setup for a one-database hosting plan

1. Keep your existing database.
2. Import the sanitized file `apartment_management_shared_db_safe.sql` instead of the original dump.
3. Point this app at your existing database by setting:
   - `DB_HOST`
   - `DB_USER`
   - `DB_PASS`
   - `DB_NAME`

If environment variables are not available on your host, you can place the same values directly in `config.php`.

### Notes

- The shared-db import file removes the destructive `DROP TABLE IF EXISTS` lines.
- Based on the provided `ngkbhmpg_modmenu.sql` dump, the apartment project table names do not exactly match your existing table names, which makes side-by-side use practical.
- Always take a fresh backup before importing anything into a production database.
